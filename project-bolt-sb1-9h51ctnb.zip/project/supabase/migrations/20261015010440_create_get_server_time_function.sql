/*
  Returns the database server's current time so the frontend can
  compare it against created_at without any browser-clock mismatch.
*/
CREATE OR REPLACE FUNCTION get_server_time()
RETURNS timestamptz
LANGUAGE sql
AS $$
  SELECT now();
$$;

GRANT EXECUTE ON FUNCTION get_server_time() TO anon, authenticated;
