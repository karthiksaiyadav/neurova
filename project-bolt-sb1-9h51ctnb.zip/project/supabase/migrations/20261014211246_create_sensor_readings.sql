/*
# Create sensor_readings table for live ESP32 data

## Purpose
Stores live grain-storage sensor readings sent from an ESP32 device
(NEUROVA Raw Paddy Rice Storage Monitor) via an edge function.

## New Tables
- `sensor_readings`
  - `id` (bigserial, primary key)
  - `device_id` (text, identifies the ESP32 device / sensor node)
  - `temperature` (real, °C from DHT22)
  - `humidity` (real, % RH from DHT22)
  - `vibration_amplitude` (integer, ADC counts from piezo)
  - `vibration_event` (boolean, true when piezo threshold crossed)
  - `temperature_warning` (boolean, true when temp > 35°C)
  - `humidity_warning` (boolean, true when RH > 65%)
  - `total_risk` (real, combined 0–100 risk score from ESP32)
  - `risk_alert` (boolean, true when total_risk > 30)
  - `created_at` (timestamptz, defaults to now())

## Security
- RLS enabled on `sensor_readings`.
- This is a single-tenant app with no sign-in screen, so anon + authenticated
  can read and insert. Updates and deletes are not needed from the frontend.
*/

CREATE TABLE IF NOT EXISTS sensor_readings (
  id bigserial PRIMARY KEY,
  device_id text NOT NULL DEFAULT 'NEUROVA-ESP32',
  temperature real,
  humidity real,
  vibration_amplitude integer,
  vibration_event boolean DEFAULT false,
  temperature_warning boolean DEFAULT false,
  humidity_warning boolean DEFAULT false,
  total_risk real,
  risk_alert boolean DEFAULT false,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE sensor_readings ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_readings" ON sensor_readings;
CREATE POLICY "anon_select_readings" ON sensor_readings FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_readings" ON sensor_readings;
CREATE POLICY "anon_insert_readings" ON sensor_readings FOR INSERT
  TO anon, authenticated WITH CHECK (true);

CREATE INDEX IF NOT EXISTS idx_sensor_readings_created_at
  ON sensor_readings (created_at DESC);

CREATE INDEX IF NOT EXISTS idx_sensor_readings_device
  ON sensor_readings (device_id, created_at DESC);
