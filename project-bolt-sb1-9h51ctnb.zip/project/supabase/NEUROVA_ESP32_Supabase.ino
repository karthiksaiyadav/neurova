/*
 * NEUROVA - RAW PADDY RICE STORAGE MONITOR
 * ESP32 + DHT22 + PIEZO + SUPABASE
 * -----------------------------------------------
 * This version replaces the ThingSpeak upload with
 * a POST to the Supabase sensor-ingest edge function.
 *
 * Hardware: ESP32 + DHT22 on GPIO4 + Piezo on GPIO34
 * Library:  ArduinoJson by Benoit Blanchon
 * -----------------------------------------------
 */

#include <WiFi.h>
#include <HTTPClient.h>
#include <DHT.h>
#include <ArduinoJson.h>

// ================== WIFI ==================
const char* WIFI_SSID     = "VNRVJIET_E";
const char* WIFI_PASSWORD = "vnrvjiet@123";

// ================== SUPABASE ==================
const char* SUPABASE_URL =
    "https://dhasmvkonmhmqaerslpo.supabase.co/functions/v1/sensor-ingest";

// ================== PINS ==================
#define DHT_PIN   4
#define DHT_TYPE  DHT22
#define PIEZO_PIN 34

DHT dht(DHT_PIN, DHT_TYPE);

// ================== RISK THRESHOLDS ==================
const float TEMP_BASELINE  = 25.0;
const float TEMP_WARNING   = 35.0;
const float RH_BASELINE    = 55.0;
const float RH_WARNING     = 65.0;
const float RH_HIGH        = 75.0;
const float RISK_ALERT_LIMIT = 30.0;

const int PIEZO_EVENT_THRESHOLD = 250;
const int PIEZO_FULL_SCALE      = 1000;

const float W_VIBRATION   = 0.40;
const float W_HUMIDITY    = 0.30;
const float W_TEMPERATURE = 0.30;

// ================== TIMING ==================
const unsigned long DHT_INTERVAL      = 2500;
const unsigned long PIEZO_INTERVAL    = 100;
const unsigned long PIEZO_WINDOW_US   = 50000;
const unsigned long CLOUD_INTERVAL    = 20000;
const unsigned long WIFI_RETRY        = 10000;
const unsigned long EVENT_COOLDOWN    = 2000;
const unsigned long DISPLAY_INTERVAL  = 2500;

// ================== STATE ==================
float temperature = NAN;
float humidity    = NAN;

int piezoMinimum       = 0;
int piezoMaximum       = 0;
int vibrationAmplitude = 0;

float vibrationRisk   = 0.0;
float humidityRisk    = 0.0;
float temperatureRisk = 0.0;
float totalRisk       = 0.0;

bool environmentValid       = false;
bool humidityWarning        = false;
bool temperatureWarning     = false;
bool riskAlert              = false;
bool vibrationEventPending  = false;

unsigned long lastDHTRead       = 0;
unsigned long lastPiezoSample   = 0;
unsigned long lastCloudUpdate   = 0;
unsigned long lastWiFiRetry     = 0;
unsigned long lastVibrationEvent = 0;
unsigned long lastDisplay       = 0;

// ================== HELPERS ==================
float clamp100(float v) {
  if (v < 0.0)  return 0.0;
  if (v > 100.0) return 100.0;
  return v;
}

// ================== WIFI ==================
void connectWiFi() {
  WiFi.mode(WIFI_STA);
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
  Serial.print("Connecting to Wi-Fi");
  unsigned long start = millis();
  while (WiFi.status() != WL_CONNECTED &&
         millis() - start < 20000) {
    delay(500);
    Serial.print(".");
  }
  if (WiFi.status() == WL_CONNECTED) {
    Serial.println("\nWi-Fi connected! IP: ");
    Serial.println(WiFi.localIP());
  } else {
    Serial.println("\nWi-Fi unavailable; will retry.");
  }
}

// ================== DHT22 ==================
void readEnvironment() {
  float h = dht.readHumidity();
  float t = dht.readTemperature();

  if (isnan(h) || isnan(t) ||
      h < 0.0 || h > 100.0 ||
      t < -40.0 || t > 80.0) {
    Serial.println("ERROR: Invalid DHT22 reading.");
    environmentValid = false;
    return;
  }
  humidity    = h;
  temperature = t;
  environmentValid = true;
  humidityWarning    = humidity > RH_WARNING;
  temperatureWarning = temperature > TEMP_WARNING;
}

// ================== PIEZO ==================
void readPiezo() {
  int minVal = 4095;
  int maxVal = 0;
  unsigned long start = micros();
  while ((unsigned long)(micros() - start) < PIEZO_WINDOW_US) {
    int v = analogRead(PIEZO_PIN);
    if (v < minVal) minVal = v;
    if (v > maxVal) maxVal = v;
  }
  piezoMinimum       = minVal;
  piezoMaximum       = maxVal;
  vibrationAmplitude = maxVal - minVal;
  vibrationRisk = clamp100(
    (float)vibrationAmplitude * 100.0 / PIEZO_FULL_SCALE);

  unsigned long now = millis();
  if (vibrationAmplitude >= PIEZO_EVENT_THRESHOLD &&
      (lastVibrationEvent == 0 ||
       now - lastVibrationEvent >= EVENT_COOLDOWN)) {
    lastVibrationEvent    = now;
    vibrationEventPending = true;
    Serial.println("VIBRATION EVENT: Threshold crossed.");
  }
}

// ================== RISK ==================
void calculateRisk() {
  if (!environmentValid) {
    totalRisk  = NAN;
    riskAlert  = false;
    return;
  }
  temperatureRisk = clamp100(
    (temperature - TEMP_BASELINE) /
    (TEMP_WARNING - TEMP_BASELINE) * 100.0);
  humidityRisk = clamp100(
    (humidity - RH_BASELINE) /
    (RH_HIGH - RH_BASELINE) * 100.0);
  totalRisk = clamp100(
    W_VIBRATION * vibrationRisk +
    W_HUMIDITY * humidityRisk +
    W_TEMPERATURE * temperatureRisk);
  riskAlert = totalRisk > RISK_ALERT_LIMIT;
}

// ================== SERIAL ==================
void printResults() {
  Serial.println("\n========== NEUROVA ==========");
  Serial.println("Material: RAW PADDY RICE");
  if (environmentValid) {
    Serial.print("Temperature: ");  Serial.print(temperature, 1); Serial.println(" C");
    Serial.print("Humidity: ");     Serial.print(humidity, 1);    Serial.println(" %");
    Serial.print("Risk: ");         Serial.print(totalRisk, 1);   Serial.println(" / 100");
    Serial.print("Alert: ");        Serial.println(riskAlert ? "ACTIVE" : "CLEAR");
  } else {
    Serial.println("ENVIRONMENT: INVALID");
  }
  Serial.print("Vibration amp: ");  Serial.print(vibrationAmplitude);
  Serial.print("  risk: ");         Serial.print(vibrationRisk, 1);
  Serial.println(" / 100");
  Serial.println("=============================");
}

// ================== SUPABASE UPLOAD ==================
void sendToSupabase() {
  if (WiFi.status() != WL_CONNECTED) {
    Serial.println("Upload skipped: Wi-Fi disconnected.");
    return;
  }
  if (!environmentValid || isnan(totalRisk)) {
    Serial.println("Upload skipped: invalid sensor data.");
    return;
  }

  // Build JSON body with ArduinoJson
  StaticJsonDocument<256> doc;
  doc["device_id"]           = "NEUROVA-ESP32";
  doc["temperature"]         = temperature;
  doc["humidity"]            = humidity;
  doc["vibration_amplitude"] = vibrationAmplitude;
  doc["vibration_event"]     = vibrationEventPending;
  doc["temperature_warning"] = temperatureWarning;
  doc["humidity_warning"]    = humidityWarning;
  doc["total_risk"]          = totalRisk;
  doc["risk_alert"]          = riskAlert;

  String jsonBody;
  serializeJson(doc, jsonBody);

  HTTPClient http;
  http.setConnectTimeout(5000);
  http.setTimeout(5000);

  http.begin(SUPABASE_URL);
  http.addHeader("Content-Type", "application/json");

  int code = http.POST(jsonBody);

  if (code == HTTP_CODE_OK) {
    String resp = http.getString();
    Serial.print("Supabase upload OK. Entry: ");
    Serial.println(resp);
    vibrationEventPending = false;
  } else {
    Serial.print("Supabase upload failed. HTTP code: ");
    Serial.println(code);
  }

  http.end();
}

// ================== SETUP ==================
void setup() {
  Serial.begin(115200);
  delay(1000);
  Serial.println("\n================================");
  Serial.println("NEUROVA - RAW PADDY MONITOR");
  Serial.println("ESP32 + DHT22 + PIEZO + SUPABASE");
  Serial.println("================================");

  analogReadResolution(12);
  analogSetPinAttenuation(PIEZO_PIN, ADC_11db);
  pinMode(PIEZO_PIN, INPUT);

  dht.begin();
  connectWiFi();

  lastDHTRead     = millis() - DHT_INTERVAL;
  lastPiezoSample = millis() - PIEZO_INTERVAL;
  lastCloudUpdate = millis() - CLOUD_INTERVAL;
  lastDisplay     = millis();
}

// ================== LOOP ==================
void loop() {
  unsigned long now = millis();

  if (WiFi.status() != WL_CONNECTED &&
      now - lastWiFiRetry >= WIFI_RETRY) {
    lastWiFiRetry = now;
    Serial.println("Retrying Wi-Fi...");
    WiFi.reconnect();
  }

  if (now - lastDHTRead >= DHT_INTERVAL) {
    lastDHTRead = now;
    readEnvironment();
  }

  now = millis();
  if (now - lastPiezoSample >= PIEZO_INTERVAL) {
    lastPiezoSample = now;
    readPiezo();
  }

  calculateRisk();

  now = millis();
  if (now - lastDisplay >= DISPLAY_INTERVAL) {
    lastDisplay = now;
    printResults();
  }

  now = millis();
  if (now - lastCloudUpdate >= CLOUD_INTERVAL) {
    lastCloudUpdate = now;
    sendToSupabase();
  }

  delay(10);
}
