import { createClient } from "npm:@supabase/supabase-js@2.57.4";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const supabase = createClient(supabaseUrl, supabaseServiceKey);

interface SensorPayload {
  device_id?: string;
  temperature?: number;
  humidity?: number;
  vibration_amplitude?: number;
  vibration_event?: boolean;
  temperature_warning?: boolean;
  humidity_warning?: boolean;
  total_risk?: number;
  risk_alert?: boolean;
}

function toBool(v: unknown): boolean {
  if (typeof v === "boolean") return v;
  if (typeof v === "number") return v !== 0;
  if (typeof v === "string") return v === "true" || v === "1";
  return false;
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  if (req.method !== "POST") {
    return new Response(
      JSON.stringify({ error: "Method not allowed. Use POST." }),
      { status: 405, headers: { ...corsHeaders, "Content-Type": "application/json" } },
    );
  }

  try {
    const body: SensorPayload | SensorPayload[] = await req.json();

    const rows = Array.isArray(body) ? body : [body];

    if (rows.length === 0) {
      return new Response(
        JSON.stringify({ error: "Empty payload." }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } },
      );
    }

    const inserts = rows.map((row) => {
      const temperature = row.temperature ?? null;
      const humidity = row.humidity ?? null;
      const vibrationAmplitude = row.vibration_amplitude ?? null;

      const TEMP_WARNING = 35.0;
      const RH_WARNING = 65.0;
      const RH_HIGH = 75.0;
      const PIEZO_EVENT_THRESHOLD = 250;
      const RISK_ALERT_LIMIT = 30.0;

      const temperatureWarning = temperature !== null && temperature > TEMP_WARNING;
      const humidityWarning = humidity !== null && humidity > RH_WARNING;
      const humidityHigh = humidity !== null && humidity > RH_HIGH;
      const vibrationEvent = toBool(row.vibration_event) ||
        (vibrationAmplitude !== null && vibrationAmplitude >= PIEZO_EVENT_THRESHOLD);

      const espRisk = row.total_risk ?? null;
      const espAlert = toBool(row.risk_alert);
      const riskAlert = espAlert || (espRisk !== null && espRisk > RISK_ALERT_LIMIT);

      return {
        device_id: row.device_id ?? "NEUROVA-ESP32",
        temperature,
        humidity,
        vibration_amplitude: vibrationAmplitude,
        vibration_event: vibrationEvent,
        temperature_warning: temperatureWarning,
        humidity_warning: humidityWarning || humidityHigh,
        total_risk: espRisk,
        risk_alert: riskAlert,
      };
    });

    const { data, error } = await supabase
      .from("sensor_readings")
      .insert(inserts)
      .select("id, created_at");

    if (error) {
      return new Response(
        JSON.stringify({ error: error.message }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } },
      );
    }

    return new Response(
      JSON.stringify({ success: true, count: data.length, entries: data }),
      { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } },
    );
  } catch (err) {
    return new Response(
      JSON.stringify({ error: err.message }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } },
    );
  }
});
