import { createClient } from "@supabase/supabase-js";

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export interface SensorReading {
  id: number;
  device_id: string;
  temperature: number | null;
  humidity: number | null;
  vibration_amplitude: number | null;
  vibration_event: boolean;
  temperature_warning: boolean;
  humidity_warning: boolean;
  total_risk: number | null;
  risk_alert: boolean;
  created_at: string;
}

export const ALERT_THRESHOLDS = {
  tempWarning: 35.0,
  rhWarning: 65.0,
  rhHigh: 75.0,
  piezoEventThreshold: 250,
  riskAlertLimit: 30.0,
};

export function computeAlerts(r: SensorReading): SensorReading {
  const temperatureWarning =
    r.temperature !== null && r.temperature > ALERT_THRESHOLDS.tempWarning;
  const humidityWarning =
    r.humidity !== null && r.humidity > ALERT_THRESHOLDS.rhWarning;
  const vibrationEvent =
    r.vibration_event ||
    (r.vibration_amplitude !== null && r.vibration_amplitude >= ALERT_THRESHOLDS.piezoEventThreshold);
  const riskAlert =
    r.risk_alert ||
    (r.total_risk !== null && r.total_risk > ALERT_THRESHOLDS.riskAlertLimit);

  return {
    ...r,
    temperature_warning: temperatureWarning,
    humidity_warning: humidityWarning,
    vibration_event: vibrationEvent,
    risk_alert: riskAlert,
  };
}
