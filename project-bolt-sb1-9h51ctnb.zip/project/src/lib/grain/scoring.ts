import type { NormalizedRow } from "./csv";

export interface BinScore {
  sensor_id: string;
  overall: number;
  temperature: number;
  humidity: number;
  riskLevel: "safe" | "caution" | "warning" | "critical";
  readingCount: number;
  latestReading: NormalizedRow;
  avgTemp: number | null;
  avgHumidity: number | null;
  maxTemp: number | null;
  maxHumidity: number | null;
  trend: "stable" | "rising" | "falling";
}

export interface OverallScore {
  overall: number;
  bins: BinScore[];
  totalReadings: number;
  safeBins: number;
  cautionBins: number;
  warningBins: number;
  criticalBins: number;
  worstBin: BinScore | null;
}

function scoreTemperature(avg: number | null, max: number | null): number {
  if (avg === null) return 50;
  let score = 100;
  if (avg > 15) score -= (avg - 15) * 4;
  if (avg > 25) score -= (avg - 25) * 6;
  if (max !== null && max > 30) score -= (max - 30) * 3;
  return Math.max(0, Math.min(100, score));
}

function scoreHumidity(avg: number | null, max: number | null): number {
  if (avg === null) return 50;
  let score = 100;
  if (avg > 55) score -= (avg - 55) * 1.5;
  if (avg > 65) score -= (avg - 65) * 2.5;
  if (avg > 75) score -= (avg - 75) * 3;
  if (max !== null && max > 80) score -= (max - 80) * 2;
  return Math.max(0, Math.min(100, score));
}

function riskFromScore(score: number): "safe" | "caution" | "warning" | "critical" {
  if (score >= 80) return "safe";
  if (score >= 60) return "caution";
  if (score >= 40) return "warning";
  return "critical";
}

function detectTrend(rows: NormalizedRow[]): "stable" | "rising" | "falling" {
  if (rows.length < 4) return "stable";
  const quarter = Math.floor(rows.length / 4);
  const first = rows.slice(0, quarter);
  const last = rows.slice(-quarter);
  const avgFirst = avg(first.map((r) => r.temperature).filter((v): v is number => v !== null));
  const avgLast = avg(last.map((r) => r.temperature).filter((v): v is number => v !== null));
  if (avgFirst === null || avgLast === null) return "stable";
  const diff = avgLast - avgFirst;
  if (diff > 1.5) return "rising";
  if (diff < -1.5) return "falling";
  return "stable";
}

function avg(nums: number[]): number | null {
  if (nums.length === 0) return null;
  return nums.reduce((a, b) => a + b, 0) / nums.length;
}

export function scoreDataset(rows: NormalizedRow[]): OverallScore {
  const byBin = new Map<string, NormalizedRow[]>();
  for (const row of rows) {
    if (!row.sensor_id) continue;
    const existing = byBin.get(row.sensor_id) ?? [];
    existing.push(row);
    byBin.set(row.sensor_id, existing);
  }

  const bins: BinScore[] = [];

  for (const [sensorId, binRows] of byBin) {
    const temps = binRows.map((r) => r.temperature).filter((v): v is number => v !== null);
    const humidities = binRows.map((r) => r.humidity).filter((v): v is number => v !== null);

    const avgTemp = avg(temps);
    const avgHumidity = avg(humidities);
    const maxTemp = temps.length ? Math.max(...temps) : null;
    const maxHumidity = humidities.length ? Math.max(...humidities) : null;

    const tempScore = scoreTemperature(avgTemp, maxTemp);
    const humidScore = scoreHumidity(avgHumidity, maxHumidity);

    const overall = Math.round((tempScore * 0.55 + humidScore * 0.45));

    bins.push({
      sensor_id: sensorId,
      overall,
      temperature: Math.round(tempScore),
      humidity: Math.round(humidScore),
      riskLevel: riskFromScore(overall),
      readingCount: binRows.length,
      latestReading: binRows[binRows.length - 1],
      avgTemp: avgTemp !== null ? parseFloat(avgTemp.toFixed(1)) : null,
      avgHumidity: avgHumidity !== null ? parseFloat(avgHumidity.toFixed(1)) : null,
      maxTemp: maxTemp !== null ? parseFloat(maxTemp.toFixed(1)) : null,
      maxHumidity: maxHumidity !== null ? parseFloat(maxHumidity.toFixed(1)) : null,
      trend: detectTrend(binRows),
    });
  }

  bins.sort((a, b) => a.overall - b.overall);

  const safeBins = bins.filter((b) => b.riskLevel === "safe").length;
  const cautionBins = bins.filter((b) => b.riskLevel === "caution").length;
  const warningBins = bins.filter((b) => b.riskLevel === "warning").length;
  const criticalBins = bins.filter((b) => b.riskLevel === "critical").length;

  const overallScore = bins.length > 0
    ? Math.round(bins.reduce((sum, b) => sum + b.overall, 0) / bins.length)
    : 0;

  return {
    overall: overallScore,
    bins,
    totalReadings: rows.length,
    safeBins,
    cautionBins,
    warningBins,
    criticalBins,
    worstBin: bins[0] ?? null,
  };
}
