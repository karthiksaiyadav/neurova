import type { NormalizedRow } from "./csv";
import { normalizeRows, autoMap, parseCsv } from "./csv";

export const SAMPLE_LABEL = "12 bins · 7 days · 10-min interval";
export const SAMPLE_NOTES = [
  "Twelve storage bins across two sites with realistic temperature and humidity drift.",
  "Readings every 10 minutes for 7 days — 12 096 rows in total.",
  "Two bins are deliberately degrading to show how the scoring flags risk early.",
  "Everything is generated in your browser, so the sample never touches a server.",
];

function seededRandom(seed: number): () => number {
  let s = seed;
  return () => {
    s = (s * 9301 + 49297) % 233280;
    return s / 233280;
  };
}

const BIN_NAMES = [
  "BIN-A1", "BIN-A2", "BIN-A3", "BIN-A4",
  "BIN-A5", "BIN-A6", "BIN-B1", "BIN-B2",
  "BIN-B3", "BIN-B4", "BIN-B5", "BIN-B6",
];

export function generateSampleData(): NormalizedRow[] {
  const rand = seededRandom(42);
  const rows: NormalizedRow[] = [];
  const startDate = new Date("2025-09-01T00:00:00Z");
  const intervalMin = 10;
  const totalDays = 7;
  const readingsPerBin = (totalDays * 24 * 60) / intervalMin;

  for (let b = 0; b < BIN_NAMES.length; b++) {
    const bin = BIN_NAMES[b];
    const baseTemp = 14 + rand() * 8;
    const baseHumidity = 45 + rand() * 20;

    const degrading = b === 4 || b === 9;

    for (let r = 0; r < readingsPerBin; r++) {
      const ts = new Date(startDate.getTime() + r * intervalMin * 60 * 1000);
      const dayProgress = r / readingsPerBin;

      const diurnal = Math.sin((r / readingsPerBin) * Math.PI * 2 * 7) * 2;

      let temp = baseTemp + diurnal + (rand() - 0.5) * 1.5;
      let humidity = baseHumidity + (rand() - 0.5) * 5;

      if (degrading) {
        temp += dayProgress * 16;
        humidity += dayProgress * 18;
      }

      rows.push({
        timestamp: ts.toISOString(),
        sensor_id: bin,
        temperature: parseFloat(temp.toFixed(1)),
        humidity: parseFloat(humidity.toFixed(1)),
      });
    }
  }

  return rows;
}

export function generateSampleCsv(): string {
  const rows = generateSampleData();
  const headers = ["timestamp", "sensor_id", "temperature", "humidity"];
  const lines = [headers.join(",")];
  for (const row of rows) {
    lines.push([row.timestamp, row.sensor_id, row.temperature, row.humidity].join(","));
  }
  return lines.join("\n");
}

export function loadSampleAsParsed() {
  const csv = generateSampleCsv();
  const parsed = parseCsv(csv);
  const mapping = autoMap(parsed.headers);
  const normalized = normalizeRows(parsed.rows, parsed.headers, mapping);
  return { parsed, mapping, normalized };
}
