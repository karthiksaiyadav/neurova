export type GrainColumn =
  | "timestamp"
  | "sensor_id"
  | "temperature"
  | "humidity";

export const COLUMN_LABELS: Record<GrainColumn, string> = {
  timestamp: "Timestamp",
  sensor_id: "Sensor / Bin ID",
  temperature: "Temperature (°C)",
  humidity: "Ambient Humidity (%)",
};

export const COLUMN_ALIASES: Record<GrainColumn, string[]> = {
  timestamp: ["timestamp", "time", "date", "datetime", "reading_time", "recorded_at", "ts"],
  sensor_id: ["sensor_id", "sensor", "bin_id", "bin", "location", "silo", "probe", "node", "device_id"],
  temperature: ["temperature", "temp", "temperature_c", "temp_c", "grain_temp", "probe_temp"],
  humidity: ["humidity", "ambient_humidity", "rh", "relative_humidity", "air_humidity"],
};

export const ALL_COLUMNS: GrainColumn[] = ["timestamp", "sensor_id", "temperature", "humidity"];

export const REQUIRED_COLUMNS: GrainColumn[] = ["timestamp", "sensor_id", "temperature"];

export interface CsvParseResult {
  headers: string[];
  rows: string[][];
}

export interface ValidationIssue {
  level: "error" | "warning";
  message: string;
  row?: number;
  column?: GrainColumn;
}

export interface ColumnStats {
  count: number;
  min: number | null;
  max: number | null;
  mean: number | null;
  unit: string;
}

export interface NormalizedRow {
  timestamp: string;
  sensor_id: string;
  temperature: number | null;
  humidity: number | null;
}

export interface NormalizeResult {
  rows: NormalizedRow[];
  issues: ValidationIssue[];
  stats: Partial<Record<GrainColumn, ColumnStats>>;
  missing: Partial<Record<GrainColumn, number>>;
}

function detectDelimiter(text: string): string {
  const firstLine = text.split(/\r?\n/)[0] ?? "";
  const candidates = [",", "\t", ";", "|"];
  let best = ",";
  let bestCount = 0;
  for (const d of candidates) {
    const count = firstLine.split(d).length - 1;
    if (count > bestCount) {
      best = d;
      bestCount = count;
    }
  }
  return best;
}

function parseLine(line: string, delimiter: string): string[] {
  const result: string[] = [];
  let current = "";
  let inQuotes = false;
  for (let i = 0; i < line.length; i++) {
    const ch = line[i];
    if (inQuotes) {
      if (ch === '"') {
        if (line[i + 1] === '"') {
          current += '"';
          i++;
        } else {
          inQuotes = false;
        }
      } else {
        current += ch;
      }
    } else {
      if (ch === '"') {
        inQuotes = true;
      } else if (ch === delimiter) {
        result.push(current.trim());
        current = "";
      } else {
        current += ch;
      }
    }
  }
  result.push(current.trim());
  return result;
}

export function parseCsv(text: string): CsvParseResult {
  const delimiter = detectDelimiter(text);
  const lines = text.split(/\r?\n/).filter((l) => l.trim().length > 0);
  if (lines.length === 0) return { headers: [], rows: [] };
  const headers = parseLine(lines[0], delimiter);
  const rows = lines.slice(1).map((l) => parseLine(l, delimiter));
  return { headers, rows };
}

export function normalizeHeader(h: string): string {
  return h.toLowerCase().replace(/[\s\-._]/g, "_").replace(/[^a-z0-9_]/g, "");
}

export function autoMap(headers: string[]): Record<string, GrainColumn | ""> {
  const mapping: Record<string, GrainColumn | ""> = {};
  const used = new Set<GrainColumn>();

  for (const header of headers) {
    const normalized = normalizeHeader(header);
    let matched: GrainColumn | "" = "";

    for (const col of ALL_COLUMNS) {
      if (used.has(col)) continue;
      const aliases = COLUMN_ALIASES[col].map(normalizeHeader);
      if (aliases.includes(normalized)) {
        matched = col;
        break;
      }
    }

    if (!matched) {
      for (const col of ALL_COLUMNS) {
        if (used.has(col)) continue;
        const aliases = COLUMN_ALIASES[col].map(normalizeHeader);
        if (aliases.some((a) => normalized.includes(a) || a.includes(normalized))) {
          matched = col;
          break;
        }
      }
    }

    if (matched) used.add(matched);
    mapping[header] = matched;
  }

  return mapping;
}

function parseNumber(value: string): number | null {
  if (!value || value.trim() === "") return null;
  const cleaned = value.replace(/[^0-9.\-+eE]/g, "");
  const n = parseFloat(cleaned);
  return isNaN(n) ? null : n;
}

const COLUMN_UNITS: Record<GrainColumn, string> = {
  timestamp: "",
  sensor_id: "",
  temperature: "°C",
  humidity: "%",
};

const COLUMN_RANGES: Partial<Record<GrainColumn, { min: number; max: number }>> = {
  temperature: { min: -40, max: 80 },
  humidity: { min: 0, max: 100 },
};

function computeStats(values: number[]): ColumnStats {
  const valid = values.filter((v) => v !== null && !isNaN(v)) as number[];
  if (valid.length === 0) {
    return { count: 0, min: null, max: null, mean: null, unit: "" };
  }
  const sum = valid.reduce((a, b) => a + b, 0);
  const col = Object.keys(COLUMN_RANGES).find(() => true);
  return {
    count: valid.length,
    min: Math.min(...valid),
    max: Math.max(...valid),
    mean: sum / valid.length,
    unit: col ? COLUMN_UNITS[col as GrainColumn] : "",
  };
}

export function normalizeRows(
  rows: string[][],
  headers: string[],
  mapping: Record<string, GrainColumn | "">,
): NormalizeResult {
  const issues: ValidationIssue[] = [];
  const missing: Partial<Record<GrainColumn, number>> = {};
  const numericValues: Partial<Record<GrainColumn, number[]>> = {};

  for (const col of ALL_COLUMNS) {
    missing[col] = 0;
    numericValues[col] = [];
  }

  for (const required of REQUIRED_COLUMNS) {
    const hasMapping = Object.values(mapping).includes(required);
    if (!hasMapping) {
      issues.push({
        level: "error",
        message: `Required column "${COLUMN_LABELS[required]}" is not mapped. Assign it in the mapping above.`,
        column: required,
      });
    }
  }

  const normalizedRows: NormalizedRow[] = rows.map((rawRow, rowIdx) => {
    const rowMap: Record<string, string> = {};
    headers.forEach((h, i) => {
      rowMap[h] = rawRow[i] ?? "";
    });

    const get = (col: GrainColumn): string => {
      const header = Object.entries(mapping).find(([, v]) => v === col)?.[0];
      return header ? rowMap[header] ?? "" : "";
    };

    const timestamp = get("timestamp");
    const sensor_id = get("sensor_id");
    const tempStr = get("temperature");
    const humidStr = get("humidity");

    if (!timestamp) missing.timestamp!++;
    if (!sensor_id) missing.sensor_id!++;
    if (!tempStr) missing.temperature!++;

    const temperature = parseNumber(tempStr);
    const humidity = parseNumber(humidStr);

    if (temperature !== null) numericValues.temperature!.push(temperature);
    if (humidity !== null) numericValues.humidity!.push(humidity);

    const rowNum = rowIdx + 1;

    for (const [col, value] of [
      ["temperature", temperature],
      ["humidity", humidity],
    ] as [GrainColumn, number | null][]) {
      const range = COLUMN_RANGES[col];
      if (range && value !== null) {
        if (value < range.min || value > range.max) {
          issues.push({
            level: "warning",
            message: `Row ${rowNum}: ${COLUMN_LABELS[col]} value ${value}${COLUMN_UNITS[col]} is outside the expected range (${range.min}–${range.max}).`,
            row: rowNum,
            column: col,
          });
        }
      }
    }

    if (REQUIRED_COLUMNS.includes("timestamp") && !timestamp) {
      issues.push({
        level: "error",
        message: `Row ${rowNum}: Missing timestamp.`,
        row: rowNum,
        column: "timestamp",
      });
    }

    if (REQUIRED_COLUMNS.includes("sensor_id") && !sensor_id) {
      issues.push({
        level: "warning",
        message: `Row ${rowNum}: Missing sensor/bin ID.`,
        row: rowNum,
        column: "sensor_id",
      });
    }

    return { timestamp, sensor_id, temperature, humidity };
  });

  const stats: Partial<Record<GrainColumn, ColumnStats>> = {};
  for (const col of ["temperature", "humidity"] as GrainColumn[]) {
    stats[col] = {
      ...computeStats(numericValues[col]!),
      unit: COLUMN_UNITS[col],
    };
  }

  return { rows: normalizedRows, issues, stats, missing };
}
