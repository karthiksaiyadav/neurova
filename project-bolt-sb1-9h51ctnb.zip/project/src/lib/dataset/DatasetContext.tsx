import { createContext, useCallback, useContext, useMemo, useState, type ReactNode } from "react";
import type { GrainColumn, NormalizeResult } from "@/lib/grain/csv";
import { generateSampleData } from "@/lib/grain/sample";
import type { OverallScore } from "@/lib/grain/scoring";
import { scoreDataset } from "@/lib/grain/scoring";

interface DatasetState {
  rows: NormalizeResult["rows"];
  mapping: Record<string, GrainColumn | "">;
  fileName: string | null;
  stats: NormalizeResult["stats"];
  isLoaded: boolean;
  isSample: boolean;
}

interface DatasetContextValue extends DatasetState {
  loadCsv: (data: { rows: NormalizeResult["rows"]; mapping: Record<string, GrainColumn | "">; fileName: string; stats: NormalizeResult["stats"] }) => void;
  loadSample: () => void;
  clear: () => void;
  score: OverallScore | null;
}

const DatasetContext = createContext<DatasetContextValue | null>(null);

const emptyState: DatasetState = {
  rows: [],
  mapping: {},
  fileName: null,
  stats: {},
  isLoaded: false,
  isSample: false,
};

export function DatasetProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<DatasetState>(emptyState);

  const loadCsv = useCallback((data: { rows: NormalizeResult["rows"]; mapping: Record<string, GrainColumn | "">; fileName: string; stats: NormalizeResult["stats"] }) => {
    setState({
      rows: data.rows,
      mapping: data.mapping,
      fileName: data.fileName,
      stats: data.stats,
      isLoaded: true,
      isSample: false,
    });
  }, []);

  const loadSample = useCallback(() => {
    const rows = generateSampleData();
    setState({
      rows,
      mapping: {},
      fileName: "sample-dataset.csv",
      stats: {},
      isLoaded: true,
      isSample: true,
    });
  }, []);

  const clear = useCallback(() => setState(emptyState), []);

  const score = useMemo(() => (state.rows.length > 0 ? scoreDataset(state.rows) : null), [state.rows]);

  const value = useMemo<DatasetContextValue>(
    () => ({ ...state, loadCsv, loadSample, clear, score }),
    [state, loadCsv, loadSample, clear, score],
  );

  return <DatasetContext.Provider value={value}>{children}</DatasetContext.Provider>;
}

export function useDataset() {
  const ctx = useContext(DatasetContext);
  if (!ctx) throw new Error("useDataset must be used within a DatasetProvider");
  return ctx;
}
