import { Activity, AlertTriangle, CheckCircle2, TrendingUp, XCircle } from "lucide-react";
import { SectionCard } from "@/components/common/SectionCard";
import { PageHeader } from "@/components/layout/PageHeader";
import { StatusPill } from "@/components/layout/StatusPill";
import { Button } from "@/components/ui/button";
import { useDataset } from "@/lib/dataset/DatasetContext";
import type { BinScore } from "@/lib/grain/scoring";
import type { ReactNode } from "react";

interface DashboardPageProps {
  onNavigate: (page: string) => void;
}

export function DashboardPage({ onNavigate }: DashboardPageProps) {
  const { score, isSample, fileName, rows } = useDataset();

  if (!score) return null;

  const riskColors: Record<string, string> = {
    safe: "bg-success-500",
    caution: "bg-warning-400",
    warning: "bg-warning-500",
    critical: "bg-destructive-500",
  };

  const riskBg: Record<string, string> = {
    safe: "border-success-200 bg-success-soft",
    caution: "border-warning-200 bg-warning-soft",
    warning: "border-warning-300 bg-warning-soft",
    critical: "border-destructive-200 bg-destructive-soft",
  };

  return (
    <div className="mx-auto max-w-6xl">
      <PageHeader
        title="Dashboard"
        subtitle={isSample ? "Sample dataset — generated in your browser" : `Source: ${fileName ?? "uploaded CSV"}`}
      >
        <StatusPill />
      </PageHeader>

      <div className="mb-6 grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-5">
        <StatCard
          icon={<Activity className="h-4 w-4" />}
          label="Overall Score"
          value={score.overall}
          sub="0–100 scale"
          accent={score.overall >= 80 ? "success" : score.overall >= 60 ? "warning" : "destructive"}
        />
        <StatCard icon={<CheckCircle2 className="h-4 w-4" />} label="Safe Bins" value={score.safeBins} accent="success" />
        <StatCard icon={<AlertTriangle className="h-4 w-4" />} label="Caution" value={score.cautionBins} accent="warning" />
        <StatCard icon={<TrendingUp className="h-4 w-4" />} label="Warning" value={score.warningBins} accent="warning" />
        <StatCard icon={<XCircle className="h-4 w-4" />} label="Critical" value={score.criticalBins} accent="destructive" />
      </div>

      <div className="mb-6 grid grid-cols-1 gap-4 lg:grid-cols-3">
        <div className="lg:col-span-2">
          <SectionCard title="Bin risk overview" description={`${score.bins.length} bins ranked from worst to best overall score`}>
            <div className="space-y-2">
              {score.bins.map((bin) => (
                <button
                  key={bin.sensor_id}
                  onClick={() => onNavigate("bins")}
                  className="flex w-full items-center gap-3 rounded-xl border border-secondary-200 bg-white p-3 text-left transition-all hover:border-primary-300 hover:bg-primary-50/30"
                >
                  <div className={`h-2 w-2 shrink-0 rounded-full ${riskColors[bin.riskLevel]}`} />
                  <span className="w-20 shrink-0 font-mono text-xs font-medium text-secondary-800">{bin.sensor_id}</span>
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <div className="h-2 flex-1 overflow-hidden rounded-full bg-secondary-100">
                        <div
                          className={`h-full rounded-full transition-all ${
                            bin.overall >= 80 ? "bg-success-500" : bin.overall >= 60 ? "bg-warning-400" : "bg-destructive-500"
                          }`}
                          style={{ width: `${bin.overall}%` }}
                        />
                      </div>
                      <span className="w-9 text-right text-xs font-bold tabular-nums text-secondary-700">{bin.overall}</span>
                    </div>
                  </div>
                  <div className="hidden gap-3 text-[11px] tabular-nums text-secondary-400 sm:flex">
                    <span>T:{bin.avgTemp ?? "—"}°</span>
                    <span>H:{bin.avgHumidity ?? "—"}%</span>
                  </div>
                </button>
              ))}
            </div>
          </SectionCard>
        </div>

        <div className="space-y-4">
          {score.worstBin ? (
            <SectionCard title="Highest risk bin" description="The bin with the lowest overall score">
              <BinDetailCard bin={score.worstBin} riskBg={riskBg[score.worstBin.riskLevel]} />
            </SectionCard>
          ) : null}

          <SectionCard title="Dataset summary" description="Quick numbers for this dataset">
            <dl className="space-y-2 text-xs">
              <div className="flex justify-between">
                <dt className="text-secondary-400">Total readings</dt>
                <dd className="font-semibold tabular-nums text-secondary-700">{rows.length.toLocaleString()}</dd>
              </div>
              <div className="flex justify-between">
                <dt className="text-secondary-400">Bins monitored</dt>
                <dd className="font-semibold tabular-nums text-secondary-700">{score.bins.length}</dd>
              </div>
              <div className="flex justify-between">
                <dt className="text-secondary-400">Safe bins</dt>
                <dd className="font-semibold tabular-nums text-success-foreground">{score.safeBins}</dd>
              </div>
              <div className="flex justify-between">
                <dt className="text-secondary-400">At-risk bins</dt>
                <dd className="font-semibold tabular-nums text-destructive-foreground">{score.warningBins + score.criticalBins}</dd>
              </div>
            </dl>
          </SectionCard>

          <Button variant="outline" className="w-full" onClick={() => onNavigate("trends")}>
            <TrendingUp className="h-4 w-4" />
            View trends
          </Button>
        </div>
      </div>
    </div>
  );
}

function BinDetailCard({ bin, riskBg }: { bin: BinScore; riskBg: string }) {
  return (
    <div className={`rounded-xl border p-3 ${riskBg}`}>
      <div className="flex items-center justify-between">
        <span className="font-mono text-sm font-bold text-secondary-900">{bin.sensor_id}</span>
        <span className="text-2xl font-bold tabular-nums text-secondary-900">{bin.overall}</span>
      </div>
      <div className="mt-3 grid grid-cols-2 gap-2 text-xs">
        <div>
          <p className="text-secondary-400">Temp</p>
          <p className="font-bold tabular-nums text-secondary-800">{bin.avgTemp ?? "—"}°C</p>
        </div>
        <div>
          <p className="text-secondary-400">Humidity</p>
          <p className="font-bold tabular-nums text-secondary-800">{bin.avgHumidity ?? "—"}%</p>
        </div>
      </div>
      <div className="mt-3 flex items-center gap-1.5 text-[11px] text-secondary-500">
        <span className={`inline-block rounded-full px-2 py-0.5 font-semibold uppercase ${
          bin.trend === "rising" ? "bg-destructive-soft text-destructive-foreground" :
          bin.trend === "falling" ? "bg-success-soft text-success-foreground" :
          "bg-secondary-100 text-secondary-600"
        }`}>
          {bin.trend}
        </span>
        <span>{bin.readingCount.toLocaleString()} readings</span>
      </div>
    </div>
  );
}

function StatCard({
  icon,
  label,
  value,
  sub,
  accent,
}: {
  icon: ReactNode;
  label: string;
  value: number;
  sub?: string;
  accent: "success" | "warning" | "destructive";
}) {
  const accentMap = {
    success: "text-success-foreground bg-success-soft",
    warning: "text-warning-foreground bg-warning-soft",
    destructive: "text-destructive-foreground bg-destructive-soft",
  };

  return (
    <div className="rounded-2xl border border-secondary-200 bg-white p-4 shadow-sm">
      <div className={`mb-2 flex h-8 w-8 items-center justify-center rounded-lg ${accentMap[accent]}`}>{icon}</div>
      <p className="text-2xl font-bold tabular-nums text-secondary-900">{value}</p>
      <p className="text-[11px] text-secondary-400">{label}</p>
      {sub ? <p className="mt-0.5 text-[10px] text-secondary-300">{sub}</p> : null}
    </div>
  );
}
