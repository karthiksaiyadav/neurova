import { useState } from "react";
import { ChevronDown, ChevronUp } from "lucide-react";
import { PageHeader } from "@/components/layout/PageHeader";
import { StatusPill } from "@/components/layout/StatusPill";
import { useDataset } from "@/lib/dataset/DatasetContext";
import type { BinScore } from "@/lib/grain/scoring";

interface BinsPageProps {
  onNavigate: (page: string) => void;
}

type SortKey = "sensor_id" | "overall" | "temperature" | "humidity";

export function BinsPage(_: BinsPageProps) {
  const { score } = useDataset();
  const [sortKey, setSortKey] = useState<SortKey>("overall");
  const [sortDir, setSortDir] = useState<"asc" | "desc">("asc");
  const [expanded, setExpanded] = useState<string | null>(null);

  if (!score) return null;

  const sorted = [...score.bins].sort((a, b) => {
    let cmp: number;
    if (sortKey === "sensor_id") {
      cmp = a.sensor_id.localeCompare(b.sensor_id);
    } else {
      cmp = (a[sortKey] as number) - (b[sortKey] as number);
    }
    return sortDir === "asc" ? cmp : -cmp;
  });

  const toggleSort = (key: SortKey) => {
    if (sortKey === key) {
      setSortDir((d) => (d === "asc" ? "desc" : "asc"));
    } else {
      setSortKey(key);
      setSortDir("asc");
    }
  };

  const riskBadge: Record<string, string> = {
    safe: "bg-success-soft text-success-foreground border-success-200",
    caution: "bg-warning-soft text-warning-foreground border-warning-200",
    warning: "bg-warning-soft text-warning-foreground border-warning-300",
    critical: "bg-destructive-soft text-destructive-foreground border-destructive-200",
  };

  const trendBadge: Record<string, string> = {
    stable: "bg-secondary-100 text-secondary-600",
    rising: "bg-destructive-soft text-destructive-foreground",
    falling: "bg-success-soft text-success-foreground",
  };

  const SortHeader = ({ label, sortK }: { label: string; sortK: SortKey }) => (
    <th
      className="cursor-pointer select-none py-2 pr-4 font-medium transition-colors hover:text-secondary-700"
      onClick={() => toggleSort(sortK)}
    >
      <span className="inline-flex items-center gap-1">
        {label}
        {sortKey === sortK ? (
          sortDir === "asc" ? <ChevronUp className="h-3 w-3" /> : <ChevronDown className="h-3 w-3" />
        ) : null}
      </span>
    </th>
  );

  return (
    <div className="mx-auto max-w-6xl">
      <PageHeader title="Bins" subtitle="Per-bin breakdown of every sensor reading and risk score">
        <StatusPill />
      </PageHeader>

      <div className="overflow-x-auto rounded-2xl border border-secondary-200 bg-white shadow-sm scrollbar-thin">
        <table className="w-full text-left text-xs">
          <thead className="border-b border-secondary-200 bg-secondary-50 text-secondary-500">
            <tr>
              <SortHeader label="Sensor" sortK="sensor_id" />
              <SortHeader label="Overall" sortK="overall" />
              <SortHeader label="Temp" sortK="temperature" />
              <SortHeader label="Humidity" sortK="humidity" />
              <th className="py-2 pr-4 font-medium">Trend</th>
              <th className="py-2 pr-4 font-medium">Risk</th>
            </tr>
          </thead>
          <tbody>
            {sorted.map((bin) => (
              <BinRow
                key={bin.sensor_id}
                bin={bin}
                expanded={expanded === bin.sensor_id}
                onToggle={() => setExpanded((cur) => (cur === bin.sensor_id ? null : bin.sensor_id))}
                riskBadge={riskBadge[bin.riskLevel]}
                trendBadge={trendBadge[bin.trend]}
              />
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function BinRow({
  bin,
  expanded,
  onToggle,
  riskBadge,
  trendBadge,
}: {
  bin: BinScore;
  expanded: boolean;
  onToggle: () => void;
  riskBadge: string;
  trendBadge: string;
}) {
  return (
    <>
      <tr
        className="cursor-pointer border-b border-secondary-100 transition-colors hover:bg-secondary-50"
        onClick={onToggle}
      >
        <td className="py-2.5 pr-4 font-mono font-medium text-secondary-800">{bin.sensor_id}</td>
        <td className="py-2.5 pr-4">
          <div className="flex items-center gap-2">
            <span className="w-9 text-right font-bold tabular-nums text-secondary-700">{bin.overall}</span>
            <div className="h-1.5 w-16 overflow-hidden rounded-full bg-secondary-100">
              <div
                className={`h-full rounded-full ${bin.overall >= 80 ? "bg-success-500" : bin.overall >= 60 ? "bg-warning-400" : "bg-destructive-500"}`}
                style={{ width: `${bin.overall}%` }}
              />
            </div>
          </div>
        </td>
        <td className="py-2.5 pr-4 tabular-nums text-secondary-600">{bin.avgTemp ?? "—"}°C</td>
        <td className="py-2.5 pr-4 tabular-nums text-secondary-600">{bin.avgHumidity ?? "—"}%</td>
        <td className="py-2.5 pr-4">
          <span className={`inline-block rounded-full px-2 py-0.5 text-[10px] font-semibold uppercase ${trendBadge}`}>
            {bin.trend}
          </span>
        </td>
        <td className="py-2.5 pr-4">
          <span className={`inline-block rounded-full border px-2.5 py-0.5 text-[10px] font-semibold uppercase ${riskBadge}`}>
            {bin.riskLevel}
          </span>
        </td>
      </tr>
      {expanded ? (
        <tr className="bg-secondary-50/50">
          <td colSpan={6} className="px-4 py-4">
            <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
              <Detail label="Avg Temp" value={bin.avgTemp !== null ? `${bin.avgTemp}°C` : "—"} />
              <Detail label="Max Temp" value={bin.maxTemp !== null ? `${bin.maxTemp}°C` : "—"} />
              <Detail label="Avg Humidity" value={bin.avgHumidity !== null ? `${bin.avgHumidity}%` : "—"} />
              <Detail label="Max Humidity" value={bin.maxHumidity !== null ? `${bin.maxHumidity}%` : "—"} />
            </div>
            <div className="mt-3 grid grid-cols-3 gap-3">
              <ScoreBar label="Temperature" value={bin.temperature} />
              <ScoreBar label="Humidity" value={bin.humidity} />
            </div>
            <p className="mt-3 text-[11px] text-secondary-400">
              {bin.readingCount.toLocaleString()} readings · last: {bin.latestReading.timestamp || "—"}
            </p>
          </td>
        </tr>
      ) : null}
    </>
  );
}

function Detail({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-lg border border-secondary-200 bg-white p-2.5">
      <p className="text-[10px] text-secondary-400">{label}</p>
      <p className="mt-0.5 font-bold tabular-nums text-secondary-800">{value}</p>
    </div>
  );
}

function ScoreBar({ label, value }: { label: string; value: number }) {
  return (
    <div>
      <div className="mb-1 flex items-center justify-between text-[11px]">
        <span className="text-secondary-500">{label}</span>
        <span className="font-bold tabular-nums text-secondary-700">{value}</span>
      </div>
      <div className="h-1.5 overflow-hidden rounded-full bg-secondary-200">
        <div
          className={`h-full rounded-full ${value >= 80 ? "bg-success-500" : value >= 60 ? "bg-warning-400" : "bg-destructive-500"}`}
          style={{ width: `${value}%` }}
        />
      </div>
    </div>
  );
}
