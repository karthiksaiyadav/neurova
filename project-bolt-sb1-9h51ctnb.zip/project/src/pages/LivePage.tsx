import { useCallback, useEffect, useRef, useState } from "react";
import {
  Activity,
  AlertTriangle,
  Download,
  Radio,
  RefreshCw,
  Thermometer,
  Trash2,
  TrendingUp,
  Waves,
  Wifi,
  WifiOff,
  Wind,
} from "lucide-react";
import { PageHeader } from "@/components/layout/PageHeader";
import { StatusPill } from "@/components/layout/StatusPill";
import { SectionCard } from "@/components/common/SectionCard";
import { Button } from "@/components/ui/button";
import { supabase, computeAlerts, type SensorReading } from "@/lib/supabaseClient";

const OFFLINE_AFTER_SEC = 60;
const POLL_INTERVAL_MS = 3000;

const TEMP_WARNING = 35.0;
const RH_WARNING = 65.0;
const RH_HIGH = 75.0;
const PIEZO_EVENT_THRESHOLD = 250;
const RISK_ALERT_LIMIT = 30.0;

type ConnectionState = "no-data" | "live" | "stale";

interface LivePageProps {
  onNavigate: (page: string) => void;
}

export function LivePage(_: LivePageProps) {
  const [readings, setReadings] = useState<SensorReading[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [lastUpdated, setLastUpdated] = useState<Date | null>(null);
  const [autoRefresh, setAutoRefresh] = useState(true);
  const [clearing, setClearing] = useState(false);
  const [tick, setTick] = useState(0);
  const [serverAgeSec, setServerAgeSec] = useState<number | null>(null);

  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const tickRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const fetchReadings = useCallback(async () => {
    const [readingsRes, timeRes] = await Promise.all([
      supabase
        .from("sensor_readings")
        .select("*")
        .order("created_at", { ascending: false })
        .limit(100),
      supabase.rpc("get_server_time"),
    ]);

    if (readingsRes.error) {
      setError("Could not fetch live readings. Check that the ESP32 is sending data.");
      setLoading(false);
      return;
    }

    if (readingsRes.data) {
      setReadings((readingsRes.data as SensorReading[]).map(computeAlerts));
      setError(null);
      setLastUpdated(new Date());
    }

    if (timeRes.data) {
      const serverNow = new Date(timeRes.data as string).getTime();
      const latestTs = readingsRes.data?.[0]
        ? new Date(readingsRes.data[0].created_at).getTime()
        : null;
      if (latestTs !== null) {
        setServerAgeSec(Math.max(0, (serverNow - latestTs) / 1000));
      } else {
        setServerAgeSec(null);
      }
    }

    setLoading(false);
  }, []);

  useEffect(() => {
    fetchReadings();
  }, [fetchReadings]);

  useEffect(() => {
    if (autoRefresh) {
      intervalRef.current = setInterval(fetchReadings, POLL_INTERVAL_MS);
      return () => {
        if (intervalRef.current) clearInterval(intervalRef.current);
      };
    }
  }, [autoRefresh, fetchReadings]);

  useEffect(() => {
    tickRef.current = setInterval(() => setTick((t) => t + 1), 1000);
    return () => {
      if (tickRef.current) clearInterval(tickRef.current);
    };
  }, []);

  const downloadCsv = useCallback(() => {
    if (readings.length === 0) return;
    const headers = [
      "id", "created_at", "device_id", "temperature", "humidity",
      "vibration_amplitude", "vibration_event", "temperature_warning",
      "humidity_warning", "total_risk", "risk_alert",
    ];
    const lines = [headers.join(",")];
    for (const r of readings) {
      lines.push([
        r.id,
        r.created_at,
        r.device_id,
        r.temperature ?? "",
        r.humidity ?? "",
        r.vibration_amplitude ?? "",
        r.vibration_event,
        r.temperature_warning,
        r.humidity_warning,
        r.total_risk ?? "",
        r.risk_alert,
      ].join(","));
    }
    const blob = new Blob([lines.join("\n")], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `neurova-readings-${new Date().toISOString().slice(0, 19).replace(/[:T]/g, "-")}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  }, [readings]);

  const clearOldData = useCallback(async () => {
    setClearing(true);
    const { error: delError } = await supabase
      .from("sensor_readings")
      .delete()
      .neq("id", -1);

    setClearing(false);
    if (delError) {
      setError("Could not clear old readings from the database.");
      return;
    }
    setServerAgeSec(null);
    await fetchReadings();
  }, [fetchReadings]);

  const latest = readings[0] ?? null;

  const displayAge = (() => {
    void tick;
    if (serverAgeSec === null) return null;
    return Math.floor(serverAgeSec + (Date.now() - (lastUpdated?.getTime() ?? Date.now())) / 1000);
  })();

  const connectionState: ConnectionState = (() => {
    if (!latest) return "no-data";
    if (displayAge === null) return "stale";
    if (displayAge <= OFFLINE_AFTER_SEC) return "live";
    return "stale";
  })();

  const activeAlerts = getActiveAlerts(latest);
  const recentEvents = readings.filter((r) => r.vibration_event).slice(0, 8);
  const alertReadings = readings.filter((r) => r.risk_alert).slice(0, 8);

  const chartReadings = [...readings].reverse().slice(-40);

  const tempValues = chartReadings.map((r) => r.temperature).filter((v): v is number => v !== null);
  const humValues = chartReadings.map((r) => r.humidity).filter((v): v is number => v !== null);
  const riskValues = chartReadings.map((r) => r.total_risk).filter((v): v is number => v !== null);
  const vibValues = chartReadings.map((r) => r.vibration_amplitude).filter((v): v is number => v !== null);

  return (
    <div className="mx-auto max-w-6xl">
      <PageHeader title="Live Monitor" subtitle="Real-time readings from the ESP32 sensor node via Supabase">
        <div className="flex items-center gap-2">
          <Button
            size="sm"
            variant="outline"
            onClick={downloadCsv}
            disabled={readings.length === 0}
          >
            <Download className="h-3.5 w-3.5" />
            Export CSV
          </Button>
          <button
            onClick={() => setAutoRefresh((v) => !v)}
            className={`inline-flex items-center gap-1.5 rounded-full border px-3 py-1 text-[11px] font-semibold uppercase tracking-wider transition-all ${
              autoRefresh
                ? "border-success-200 bg-success-soft text-success-foreground"
                : "border-secondary-300 bg-white text-secondary-500"
            }`}
          >
            <span className={`h-1.5 w-1.5 rounded-full ${autoRefresh ? "bg-success-500 animate-pulse" : "bg-secondary-400"}`} />
            {autoRefresh ? "Auto" : "Paused"}
          </button>
          <StatusPill />
        </div>
      </PageHeader>

      {loading ? (
        <div className="flex items-center justify-center py-16">
          <div className="h-10 w-10 animate-spin rounded-full border-3 border-secondary-200 border-t-primary-500" />
        </div>
      ) : error ? (
        <SectionCard title="Connection issue" description="The live monitor could not load readings">
          <div className="rounded-xl border border-destructive bg-destructive-soft px-4 py-3 text-xs text-destructive-foreground">
            {error}
          </div>
          <Button variant="outline" className="mt-3" onClick={fetchReadings}>
            <RefreshCw className="h-4 w-4" />
            Retry
          </Button>
        </SectionCard>
      ) : connectionState === "no-data" ? (
        <SectionCard
          title="No readings yet"
          description="Waiting for the ESP32 to send its first sensor reading."
        >
          <div className="flex flex-col items-center gap-3 py-8 text-center">
            <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-secondary-100 text-secondary-400">
              <Radio className="h-7 w-7" />
            </div>
            <div>
              <p className="text-sm font-medium text-secondary-600">No data received</p>
              <p className="mt-1 text-xs text-secondary-400">
                Make sure the ESP32 is powered on, connected to Wi-Fi, and posting to the ingest endpoint.
                Check the setup instructions below.
              </p>
            </div>
            <Button variant="outline" className="mt-2" onClick={fetchReadings}>
              <RefreshCw className="h-4 w-4" />
              Refresh
            </Button>
          </div>

          <EspSetupCard />
        </SectionCard>
      ) : (
        <div className="space-y-4">
          <ConnectionBanner
            state={connectionState}
            ageSec={displayAge ?? 0}
            latestTimestamp={latest?.created_at ?? null}
          />

          {connectionState === "stale" && (
            <SectionCard
              title="ESP32 disconnected"
              description={`Last reading was ${displayAge ?? 0}s ago — no new data for over ${OFFLINE_AFTER_SEC}s.`}
            >
              <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                <p className="text-xs text-secondary-500">
                  The data below is from a previous ESP32 session and is shown for reference.
                  When the device reconnects, new readings will appear at the top automatically.
                  You can clear old test data to start fresh.
                </p>
                <div className="flex shrink-0 gap-2">
                  <Button size="sm" variant="outline" onClick={fetchReadings}>
                    <RefreshCw className="h-3.5 w-3.5" />
                    Check again
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={clearOldData}
                    disabled={clearing}
                    className="border-destructive-200 text-destructive-600 hover:bg-destructive-soft"
                  >
                    <Trash2 className="h-3.5 w-3.5" />
                    {clearing ? "Clearing..." : "Clear old data"}
                  </Button>
                </div>
              </div>
            </SectionCard>
          )}

          {activeAlerts.length > 0 && (
            <div className="space-y-2">
              {activeAlerts.map((alert, i) => (
                <div
                  key={i}
                  className={`flex items-center gap-3 rounded-xl border px-4 py-3 ${
                    alert.severity === "critical"
                      ? "border-destructive-300 bg-destructive-soft"
                      : "border-warning-300 bg-warning-soft"
                  }`}
                >
                  <div className={`flex h-8 w-8 shrink-0 items-center justify-center rounded-lg ${
                    alert.severity === "critical"
                      ? "bg-destructive-500 text-white"
                      : "bg-warning-500 text-white"
                  }`}>
                    <AlertTriangle className="h-4 w-4" />
                  </div>
                  <div className="flex-1">
                    <p className={`text-sm font-semibold ${
                      alert.severity === "critical"
                        ? "text-destructive-foreground"
                        : "text-warning-foreground"
                    }`}>{alert.title}</p>
                    <p className="text-[11px] text-secondary-500">{alert.detail}</p>
                  </div>
                </div>
              ))}
            </div>
          )}

          {latest ? (
            <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-5">
              <LiveStat
                icon={<Activity className="h-4 w-4" />}
                label="Risk Score"
                value={latest.total_risk !== null ? latest.total_risk.toFixed(1) : "—"}
                sub={`alert if > ${RISK_ALERT_LIMIT}`}
                accent={
                  latest.total_risk !== null && latest.total_risk > RISK_ALERT_LIMIT
                    ? "destructive"
                    : latest.total_risk !== null && latest.total_risk > 20
                    ? "warning"
                    : "success"
                }
                dimmed={connectionState === "stale"}
              />
              <LiveStat
                icon={<Thermometer className="h-4 w-4" />}
                label="Temperature"
                value={latest.temperature !== null ? `${latest.temperature.toFixed(1)}°C` : "—"}
                sub={`warn if > ${TEMP_WARNING}°C`}
                accent={latest.temperature_warning ? "destructive" : "secondary"}
                dimmed={connectionState === "stale"}
              />
              <LiveStat
                icon={<Wind className="h-4 w-4" />}
                label="Humidity"
                value={latest.humidity !== null ? `${latest.humidity.toFixed(1)}%` : "—"}
                sub={`warn if > ${RH_WARNING}%`}
                accent={latest.humidity_warning ? (latest.humidity !== null && latest.humidity > RH_HIGH ? "destructive" : "warning") : "secondary"}
                dimmed={connectionState === "stale"}
              />
              <LiveStat
                icon={<Waves className="h-4 w-4" />}
                label="Vibration"
                value={latest.vibration_amplitude ?? "—"}
                sub={`event if >= ${PIEZO_EVENT_THRESHOLD}`}
                accent={latest.vibration_event ? "warning" : "secondary"}
                dimmed={connectionState === "stale"}
              />
              <LiveStat
                icon={<AlertTriangle className="h-4 w-4" />}
                label="Alert Status"
                value={latest.risk_alert ? "ACTIVE" : "CLEAR"}
                sub={latest.risk_alert ? `risk > ${RISK_ALERT_LIMIT}` : "all normal"}
                accent={latest.risk_alert ? "destructive" : "success"}
                dimmed={connectionState === "stale"}
              />
            </div>
          ) : null}

          <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
            <SectionCard title="Temperature trend" description={`Last 40 readings · warn above ${TEMP_WARNING}°C`}>
              <MiniChart
                values={tempValues}
                color="#ef4444"
                unit="°C"
                threshold={TEMP_WARNING}
                thresholdLabel={`${TEMP_WARNING}°C warn`}
              />
            </SectionCard>
            <SectionCard title="Humidity trend" description={`Last 40 readings · warn above ${RH_WARNING}%`}>
              <MiniChart
                values={humValues}
                color="#f59e0b"
                unit="%"
                threshold={RH_WARNING}
                thresholdLabel={`${RH_WARNING}% warn`}
              />
            </SectionCard>
          </div>

          <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
            <SectionCard title="Vibration amplitude" description={`Last 40 readings · event at ${PIEZO_EVENT_THRESHOLD} ADC`}>
              <MiniChart
                values={vibValues}
                color="#8b5cf6"
                unit=""
                threshold={PIEZO_EVENT_THRESHOLD}
                thresholdLabel={`event ≥ ${PIEZO_EVENT_THRESHOLD}`}
              />
            </SectionCard>
            <SectionCard title="Combined risk score" description={`ESP32-computed · alert above ${RISK_ALERT_LIMIT}`}>
              <MiniChart
                values={riskValues}
                color="#14b8a6"
                unit=""
                max={100}
                threshold={RISK_ALERT_LIMIT}
                thresholdLabel={`alert > ${RISK_ALERT_LIMIT}`}
              />
            </SectionCard>
          </div>

          <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
            <SectionCard title="Risk alerts" description={`Readings where total risk exceeded ${RISK_ALERT_LIMIT}`}>
              {alertReadings.length > 0 ? (
                <div className="space-y-2">
                  {alertReadings.map((r) => (
                    <div key={r.id} className="flex items-center gap-3 rounded-lg border border-destructive-200 bg-destructive-soft px-3 py-2 text-xs">
                      <AlertTriangle className="h-3.5 w-3.5 shrink-0 text-destructive-600" />
                      <span className="font-mono text-secondary-500">{formatTime(r.created_at)}</span>
                      <span className="font-medium text-destructive-foreground">Risk {r.total_risk?.toFixed(1)}</span>
                      <span className="text-secondary-400">T:{r.temperature?.toFixed(1)}°C H:{r.humidity?.toFixed(1)}%</span>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-xs text-secondary-400">No risk alerts in the recent window.</p>
              )}
            </SectionCard>

            <SectionCard title="Vibration events" description={`Piezo amplitude crossed ${PIEZO_EVENT_THRESHOLD} ADC`}>
              {recentEvents.length > 0 ? (
                <div className="space-y-2">
                  {recentEvents.map((r) => (
                    <div key={r.id} className="flex items-center gap-3 rounded-lg border border-warning-200 bg-warning-soft px-3 py-2 text-xs">
                      <Waves className="h-3.5 w-3.5 shrink-0 text-warning-foreground" />
                      <span className="font-mono text-secondary-500">{formatTime(r.created_at)}</span>
                      <span className="font-medium text-warning-foreground">Amplitude {r.vibration_amplitude}</span>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-xs text-secondary-400">No vibration events detected.</p>
              )}
            </SectionCard>
          </div>

          <SectionCard
            title="Raw reading log"
            description={`${readings.length} readings · last updated ${lastUpdated ? formatTime(lastUpdated.toISOString()) : "—"}`}
            action={
              <Button size="sm" variant="ghost" onClick={fetchReadings}>
                <RefreshCw className="h-3.5 w-3.5" />
              </Button>
            }
          >
            <div className="max-h-64 overflow-y-auto scrollbar-thin">
              <table className="w-full text-left text-xs">
                <thead className="sticky top-0 bg-white">
                  <tr className="border-b border-secondary-200 text-secondary-400">
                    <th className="py-2 pr-3 font-medium">Time</th>
                    <th className="py-2 pr-3 font-medium">Device</th>
                    <th className="py-2 pr-3 font-medium">Temp</th>
                    <th className="py-2 pr-3 font-medium">RH</th>
                    <th className="py-2 pr-3 font-medium">Vib</th>
                    <th className="py-2 pr-3 font-medium">Risk</th>
                    <th className="py-2 pr-3 font-medium">Alert</th>
                  </tr>
                </thead>
                <tbody>
                  {readings.slice(0, 50).map((r) => {
                    const rowAge = displayAge !== null && r.id === latest?.id ? displayAge : null;
                    const isStaleRow = rowAge !== null && rowAge > OFFLINE_AFTER_SEC;
                    return (
                      <tr key={r.id} className={`border-b border-secondary-100 hover:bg-secondary-50 ${isStaleRow ? "opacity-50" : ""}`}>
                        <td className="py-1.5 pr-3 font-mono text-secondary-500">{formatTime(r.created_at)}</td>
                        <td className="py-1.5 pr-3 font-mono text-secondary-600">{r.device_id}</td>
                        <td className={`py-1.5 pr-3 tabular-nums ${r.temperature_warning ? "text-destructive-600 font-medium" : "text-secondary-700"}`}>
                          {r.temperature?.toFixed(1) ?? "—"}
                        </td>
                        <td className={`py-1.5 pr-3 tabular-nums ${r.humidity_warning ? "text-warning-600 font-medium" : "text-secondary-700"}`}>
                          {r.humidity?.toFixed(1) ?? "—"}
                        </td>
                        <td className={`py-1.5 pr-3 tabular-nums ${r.vibration_event ? "text-warning-600 font-medium" : "text-secondary-700"}`}>
                          {r.vibration_amplitude ?? "—"}
                        </td>
                        <td className={`py-1.5 pr-3 tabular-nums font-medium ${r.risk_alert ? "text-destructive-600" : "text-secondary-700"}`}>
                          {r.total_risk?.toFixed(1) ?? "—"}
                        </td>
                        <td className="py-1.5 pr-3">
                          <span className={`inline-block h-2 w-2 rounded-full ${r.risk_alert ? "bg-destructive-500" : "bg-success-500"}`} />
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </SectionCard>
        </div>
      )}
    </div>
  );
}

function getActiveAlerts(latest: SensorReading | null): Array<{ severity: "critical" | "warning"; title: string; detail: string }> {
  if (!latest) return [];
  const alerts: Array<{ severity: "critical" | "warning"; title: string; detail: string }> = [];

  if (latest.risk_alert && latest.total_risk !== null) {
    alerts.push({
      severity: "critical",
      title: `Risk alert active — score ${latest.total_risk.toFixed(1)}`,
      detail: `Combined risk exceeded ${RISK_ALERT_LIMIT}. Check temperature, humidity, and vibration immediately.`,
    });
  }

  if (latest.temperature_warning && latest.temperature !== null) {
    alerts.push({
      severity: "critical",
      title: `Temperature high — ${latest.temperature.toFixed(1)}°C`,
      detail: `Above warning threshold of ${TEMP_WARNING}°C. Grain storage temperature is too high.`,
    });
  }

  if (latest.humidity !== null && latest.humidity > RH_HIGH) {
    alerts.push({
      severity: "critical",
      title: `Humidity critical — ${latest.humidity.toFixed(1)}%`,
      detail: `Above high threshold of ${RH_HIGH}%. Moisture condensation and mold growth likely.`,
    });
  } else if (latest.humidity_warning && latest.humidity !== null) {
    alerts.push({
      severity: "warning",
      title: `Humidity elevated — ${latest.humidity.toFixed(1)}%`,
      detail: `Above warning threshold of ${RH_WARNING}%. Monitor closely for spoilage indicators.`,
    });
  }

  if (latest.vibration_event && latest.vibration_amplitude !== null) {
    alerts.push({
      severity: "warning",
      title: `Vibration event detected — amplitude ${latest.vibration_amplitude}`,
      detail: `Piezo amplitude crossed ${PIEZO_EVENT_THRESHOLD} ADC. Possible impact or pest activity.`,
    });
  }

  return alerts;
}

function ConnectionBanner({
  state,
  ageSec,
  latestTimestamp,
}: {
  state: ConnectionState;
  ageSec: number;
  latestTimestamp: string | null;
}) {
  if (state === "live") {
    return (
      <div className="flex items-center gap-3 rounded-2xl border border-success-200 bg-success-soft px-4 py-3">
        <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-success-500 text-white">
          <Wifi className="h-5 w-5" />
        </div>
        <div className="flex-1">
          <p className="text-sm font-semibold text-success-foreground">ESP32 connected — streaming live data</p>
          <p className="text-[11px] text-success-600">
            Latest reading {ageSec}s ago · {latestTimestamp ? formatTime(latestTimestamp) : "—"}
          </p>
        </div>
        <span className="flex items-center gap-1.5 rounded-full bg-success-500 px-3 py-1 text-[11px] font-bold uppercase tracking-wider text-white">
          <span className="h-1.5 w-1.5 rounded-full bg-white animate-pulse" />
          Live
        </span>
      </div>
    );
  }

  return (
    <div className="flex items-center gap-3 rounded-2xl border border-warning-200 bg-warning-soft px-4 py-3">
      <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-warning-500 text-white">
        <WifiOff className="h-5 w-5" />
      </div>
      <div className="flex-1">
        <p className="text-sm font-semibold text-warning-foreground">ESP32 offline — last reading {ageSec}s ago</p>
        <p className="text-[11px] text-warning-600">
          Last at {latestTimestamp ? formatTime(latestTimestamp) : "—"} · new data will appear automatically when the device reconnects
        </p>
      </div>
      <span className="flex items-center gap-1.5 rounded-full bg-warning-500 px-3 py-1 text-[11px] font-bold uppercase tracking-wider text-white">
        Offline
      </span>
    </div>
  );
}

function EspSetupCard() {
  return (
    <div className="mt-4 rounded-xl border border-secondary-200 bg-secondary-50 p-4">
      <p className="text-xs font-semibold text-secondary-700">ESP32 Setup — replace ThingSpeak with the Supabase ingest endpoint</p>
      <p className="mt-1 text-[11px] text-secondary-400">In your Arduino sketch, change the <code className="font-mono">sendToThingSpeak()</code> function to POST JSON to this URL instead of ThingSpeak:</p>
      <div className="mt-2 rounded-lg bg-secondary-900 p-3 font-mono text-[11px] text-secondary-100 overflow-x-auto">
        <div>POST https://dhasmvkonmhmqaerslpo.supabase.co/functions/v1/sensor-ingest</div>
        <div className="mt-1">Content-Type: application/json</div>
        <div className="mt-2 text-secondary-400">{"{"}</div>
        <div className="pl-3 text-secondary-300">"device_id": "NEUROVA-ESP32",</div>
        <div className="pl-3 text-secondary-300">"temperature": 28.5,</div>
        <div className="pl-3 text-secondary-300">"humidity": 62.3,</div>
        <div className="pl-3 text-secondary-300">"vibration_amplitude": 340,</div>
        <div className="pl-3 text-secondary-300">"vibration_event": false,</div>
        <div className="pl-3 text-secondary-300">"temperature_warning": false,</div>
        <div className="pl-3 text-secondary-300">"humidity_warning": true,</div>
        <div className="pl-3 text-secondary-300">"total_risk": 22.5,</div>
        <div className="pl-3 text-secondary-300">"risk_alert": false</div>
        <div className="text-secondary-400">{"}"}</div>
      </div>
      <p className="mt-3 text-[11px] text-secondary-400">The endpoint accepts a single object or an array of objects. No API key is required for ingestion.</p>
    </div>
  );
}

function LiveStat({
  icon,
  label,
  value,
  sub,
  accent,
  dimmed,
}: {
  icon: React.ReactNode;
  label: string;
  value: string | number;
  sub?: string;
  accent: "success" | "warning" | "destructive" | "secondary";
  dimmed?: boolean;
}) {
  const accentMap = {
    success: "text-success-foreground bg-success-soft",
    warning: "text-warning-foreground bg-warning-soft",
    destructive: "text-destructive-foreground bg-destructive-soft",
    secondary: "text-secondary-600 bg-secondary-100",
  };

  return (
    <div className={`rounded-2xl border border-secondary-200 bg-white p-4 shadow-sm transition-opacity ${dimmed ? "opacity-60" : ""}`}>
      <div className={`mb-2 flex h-8 w-8 items-center justify-center rounded-lg ${accentMap[accent]}`}>{icon}</div>
      <p className="text-xl font-bold tabular-nums text-secondary-900">{value}</p>
      <p className="text-[11px] text-secondary-400">{label}</p>
      {sub ? <p className="mt-0.5 text-[10px] text-secondary-300">{sub}</p> : null}
    </div>
  );
}

function MiniChart({
  values,
  color,
  unit,
  max,
  threshold,
  thresholdLabel,
}: {
  values: number[];
  color: string;
  unit: string;
  max?: number;
  threshold?: number;
  thresholdLabel?: string;
}) {
  if (values.length < 2) {
    return <p className="py-8 text-center text-xs text-secondary-400">Not enough data yet.</p>;
  }

  const minVal = Math.min(...values);
  const maxVal = max ?? Math.max(...values);
  const range = maxVal - minVal || 1;
  const width = 800;
  const height = 120;

  const points = values
    .map((v, i) => {
      const x = (i / (values.length - 1)) * (width - 40) + 40;
      const y = height - 20 - ((v - minVal) / range) * (height - 40);
      return `${x.toFixed(1)},${y.toFixed(1)}`;
    })
    .join(" ");

  const thresholdY =
    threshold !== undefined && threshold >= minVal && threshold <= maxVal
      ? height - 20 - ((threshold - minVal) / range) * (height - 40)
      : null;

  return (
    <div>
      <svg viewBox={`0 0 ${width} ${height}`} className="w-full" preserveAspectRatio="none" style={{ height: "120px" }}>
        {[0, 0.5, 1].map((p) => (
          <line key={p} x1={40} y1={10 + p * 90} x2={width} y2={10 + p * 90} stroke="#e2e8f0" strokeWidth={1} />
        ))}
        {thresholdY !== null && (
          <>
            <line
              x1={40}
              y1={thresholdY}
              x2={width}
              y2={thresholdY}
              stroke="#ef4444"
              strokeWidth={1}
              strokeDasharray="4 3"
              opacity={0.5}
            />
            <text x={width - 4} y={thresholdY - 3} textAnchor="end" className="fill-destructive-400 text-[9px]">
              {thresholdLabel}
            </text>
          </>
        )}
        <polyline points={points} fill="none" stroke={color} strokeWidth={2} vectorEffect="non-scaling-stroke" />
      </svg>
      <div className="mt-2 flex justify-between text-[11px] text-secondary-400">
        <span>min {minVal.toFixed(1)}{unit}</span>
        <span>max {maxVal.toFixed(1)}{unit}</span>
      </div>
    </div>
  );
}

function formatTime(iso: string): string {
  const d = new Date(iso);
  return d.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" });
}
