import { useMemo, useState } from "react";
import { PageHeader } from "@/components/layout/PageHeader";
import { StatusPill } from "@/components/layout/StatusPill";
import { SectionCard } from "@/components/common/SectionCard";
import { useDataset } from "@/lib/dataset/DatasetContext";
import type { NormalizedRow } from "@/lib/grain/csv";

interface TrendsPageProps {
  onNavigate: (page: string) => void;
}

type Metric = "temperature" | "humidity";

const METRIC_LABELS: Record<Metric, string> = {
  temperature: "Temperature (°C)",
  humidity: "Humidity (%)",
};

const METRIC_COLORS: Record<Metric, string> = {
  temperature: "#ef4444",
  humidity: "#f59e0b",
};

export function TrendsPage(_: TrendsPageProps) {
  const { rows, score } = useDataset();
  const [metric, setMetric] = useState<Metric>("temperature");

  const bins = useMemo(() => {
    if (!score) return [];
    return score.bins.map((b) => b.sensor_id);
  }, [score]);

  const [selectedBins, setSelectedBins] = useState<Set<string>>(new Set());

  const displayedBins = useMemo(() => {
    if (selectedBins.size > 0) return Array.from(selectedBins);
    return bins.slice(0, 6);
  }, [selectedBins, bins]);

  const chartData = useMemo(() => {
    const byBin = new Map<string, { ts: Date; value: number }[]>();
    for (const row of rows) {
      if (!row.sensor_id) continue;
      const value = row[metric];
      if (value === null) continue;
      const arr = byBin.get(row.sensor_id) ?? [];
      arr.push({ ts: new Date(row.timestamp), value });
      byBin.set(row.sensor_id, arr);
    }
    return byBin;
  }, [rows, metric]);

  const allValues = useMemo(() => {
    const vals: number[] = [];
    for (const bin of displayedBins) {
      const data = chartData.get(bin);
      if (data) vals.push(...data.map((d) => d.value));
    }
    return vals;
  }, [chartData, displayedBins]);

  const minVal = allValues.length ? Math.min(...allValues) : 0;
  const maxVal = allValues.length ? Math.max(...allValues) : 100;
  const valRange = maxVal - minVal || 1;

  const allTimes = useMemo(() => {
    const times: Date[] = [];
    for (const bin of displayedBins) {
      const data = chartData.get(bin);
      if (data) times.push(...data.map((d) => d.ts));
    }
    return times.sort((a, b) => a.getTime() - b.getTime());
  }, [chartData, displayedBins]);

  const minTime = allTimes.length ? allTimes[0].getTime() : 0;
  const maxTime = allTimes.length ? allTimes[allTimes.length - 1].getTime() : 1;
  const timeRange = maxTime - minTime || 1;

  if (!score) return null;

  const toggleBin = (bin: string) => {
    setSelectedBins((cur) => {
      const next = new Set(cur);
      if (next.has(bin)) next.delete(bin);
      else next.add(bin);
      return next;
    });
  };

  return (
    <div className="mx-auto max-w-6xl">
      <PageHeader title="Trends" subtitle="Sensor readings over time, per bin">
        <StatusPill />
      </PageHeader>

      <div className="mb-4 flex flex-wrap items-center gap-2">
        {(Object.keys(METRIC_LABELS) as Metric[]).map((m) => (
          <button
            key={m}
            onClick={() => setMetric(m)}
            className={`rounded-lg px-3 py-1.5 text-xs font-medium transition-all ${
              metric === m
                ? "bg-secondary-900 text-white"
                : "border border-secondary-300 bg-white text-secondary-600 hover:bg-secondary-50"
            }`}
          >
            {METRIC_LABELS[m]}
          </button>
        ))}
      </div>

      <SectionCard
        title={METRIC_LABELS[metric]}
        description="Each line is one bin. Click a bin in the legend to toggle it."
      >
        <div className="relative h-80 w-full">
          <svg viewBox="0 0 800 320" className="h-full w-full" preserveAspectRatio="none">
            {[0, 0.25, 0.5, 0.75, 1].map((p) => (
              <line
                key={p}
                x1={40}
                y1={10 + p * 290}
                x2={790}
                y2={10 + p * 290}
                stroke="#e2e8f0"
                strokeWidth={1}
              />
            ))}
            {[0, 0.25, 0.5, 0.75, 1].map((p) => (
              <text
                key={p}
                x={35}
                y={14 + p * 290}
                textAnchor="end"
                className="fill-secondary-400 text-[10px]"
              >
                {(maxVal - p * valRange).toFixed(1)}
              </text>
            ))}
            {displayedBins.map((bin) => {
              const data = chartData.get(bin);
              if (!data || data.length < 2) return null;
              const color = METRIC_COLORS[metric];
              const points = data
                .map((d) => {
                  const x = 40 + ((d.ts.getTime() - minTime) / timeRange) * 750;
                  const y = 300 - ((d.value - minVal) / valRange) * 290;
                  return `${x.toFixed(1)},${y.toFixed(1)}`;
                })
                .join(" ");
              return (
                <polyline
                  key={bin}
                  points={points}
                  fill="none"
                  stroke={color}
                  strokeWidth={1.5}
                  opacity={0.7}
                  vectorEffect="non-scaling-stroke"
                />
              );
            })}
          </svg>
        </div>

        <div className="mt-4 flex flex-wrap gap-2">
          {bins.map((bin) => {
            const active = displayedBins.includes(bin);
            return (
              <button
                key={bin}
                onClick={() => toggleBin(bin)}
                className={`rounded-full border px-3 py-1 text-[11px] font-medium transition-all ${
                  active
                    ? "border-secondary-400 bg-white text-secondary-700"
                    : "border-secondary-200 bg-secondary-50 text-secondary-400"
                }`}
              >
                {bin}
              </button>
            );
          })}
        </div>
      </SectionCard>

      <div className="mt-4 grid grid-cols-1 gap-4 sm:grid-cols-2">
        <SectionCard title="Metric summary" description={`Across ${displayedBins.length} bins`}>
          <dl className="space-y-2 text-xs">
            <div className="flex justify-between">
              <dt className="text-secondary-400">Minimum</dt>
              <dd className="font-semibold tabular-nums text-secondary-700">{minVal.toFixed(1)}</dd>
            </div>
            <div className="flex justify-between">
              <dt className="text-secondary-400">Maximum</dt>
              <dd className="font-semibold tabular-nums text-secondary-700">{maxVal.toFixed(1)}</dd>
            </div>
            <div className="flex justify-between">
              <dt className="text-secondary-400">Range</dt>
              <dd className="font-semibold tabular-nums text-secondary-700">{valRange.toFixed(1)}</dd>
            </div>
          </dl>
        </SectionCard>

        <SectionCard title="Showing" description="Bins currently displayed on the chart">
          <div className="flex flex-wrap gap-1.5">
            {displayedBins.map((bin) => (
              <span
                key={bin}
                className="rounded-lg border border-secondary-200 bg-secondary-50 px-2.5 py-0.5 font-mono text-[11px] text-secondary-600"
              >
                {bin}
              </span>
            ))}
          </div>
          {selectedBins.size === 0 ? (
            <p className="mt-2 text-[11px] text-secondary-400">First 6 bins shown by default. Click any bin above to customize.</p>
          ) : null}
        </SectionCard>
      </div>
    </div>
  );
}
