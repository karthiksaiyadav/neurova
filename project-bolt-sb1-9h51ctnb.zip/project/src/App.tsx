import { useState } from "react";
import { AppShell } from "@/components/layout/AppShell";
import { DatasetProvider } from "@/lib/dataset/DatasetContext";
import { UploadPage } from "@/pages/UploadPage";
import { DashboardPage } from "@/pages/DashboardPage";
import { BinsPage } from "@/pages/BinsPage";
import { TrendsPage } from "@/pages/TrendsPage";
import { LivePage } from "@/pages/LivePage";

function AppContent() {
  const [page, setPage] = useState("upload");

  const navigate = (p: string) => {
    setPage(p);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  return (
    <AppShell currentPage={page} onNavigate={navigate}>
      {page === "upload" ? <UploadPage onNavigate={navigate} /> : null}
      {page === "dashboard" ? <DashboardPage onNavigate={navigate} /> : null}
      {page === "bins" ? <BinsPage onNavigate={navigate} /> : null}
      {page === "trends" ? <TrendsPage onNavigate={navigate} /> : null}
      {page === "live" ? <LivePage onNavigate={navigate} /> : null}
    </AppShell>
  );
}

export default function App() {
  return (
    <DatasetProvider>
      <AppContent />
    </DatasetProvider>
  );
}
