import type { ReactNode } from "react";

interface DatasetGateProps {
  title: string;
  description: string;
  children: ReactNode;
}

export function DatasetGate({ title, description, children }: DatasetGateProps) {
  return (
    <div className="relative">
      <div className="pointer-events-none absolute inset-0 -z-10 opacity-[0.03]" style={{ backgroundImage: "radial-gradient(circle at 1px 1px, #0f172a 1px, transparent 0)", backgroundSize: "24px 24px" }} />
      <div
        className="mb-6 rounded-2xl border border-dashed border-secondary-300 bg-gradient-to-br from-white to-secondary-50 p-5"
        role="region"
        aria-label={title}
      >
        <p className="text-sm font-semibold text-secondary-700">{title}</p>
        <p className="mt-0.5 text-xs text-secondary-400">{description}</p>
      </div>
      {children}
    </div>
  );
}
