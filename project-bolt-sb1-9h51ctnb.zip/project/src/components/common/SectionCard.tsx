import type { ReactNode } from "react";

interface SectionCardProps {
  title: string;
  description?: string;
  children: ReactNode;
  action?: ReactNode;
}

export function SectionCard({ title, description, children, action }: SectionCardProps) {
  return (
    <section className="animate-fade-in rounded-2xl border border-secondary-200 bg-white p-5 shadow-sm">
      <div className="mb-4 flex items-start justify-between gap-4">
        <div>
          <h2 className="text-sm font-semibold text-secondary-900">{title}</h2>
          {description ? <p className="mt-0.5 text-xs text-secondary-500">{description}</p> : null}
        </div>
        {action}
      </div>
      {children}
    </section>
  );
}
