import type { NormalizedRow } from "@/lib/grain/csv";

interface DataPreviewTableProps {
  rows: NormalizedRow[];
  maxRows?: number;
}

export function DataPreviewTable({ rows, maxRows = 12 }: DataPreviewTableProps) {
  const display = rows.slice(0, maxRows);

  return (
    <div className="overflow-x-auto scrollbar-thin">
      <table className="w-full text-left text-xs">
        <thead>
          <tr className="border-b border-secondary-200 text-secondary-500">
            <th className="py-2 pr-4 font-medium">Timestamp</th>
            <th className="py-2 pr-4 font-medium">Sensor</th>
            <th className="py-2 pr-4 font-medium">Temp (°C)</th>
            <th className="py-2 pr-4 font-medium">Humidity (%)</th>
          </tr>
        </thead>
        <tbody>
          {display.map((row, i) => (
            <tr key={i} className="border-b border-secondary-100 transition-colors hover:bg-secondary-50">
              <td className="py-2 pr-4 font-mono text-secondary-600">{row.timestamp || "—"}</td>
              <td className="py-2 pr-4 font-medium text-secondary-700">{row.sensor_id || "—"}</td>
              <td className="py-2 pr-4 tabular-nums text-secondary-600">{row.temperature ?? "—"}</td>
              <td className="py-2 pr-4 tabular-nums text-secondary-600">{row.humidity ?? "—"}</td>
            </tr>
          ))}
        </tbody>
      </table>
      {rows.length > maxRows && (
        <p className="mt-2 text-xs text-secondary-400">
          Showing {maxRows} of {rows.length.toLocaleString()} rows
        </p>
      )}
    </div>
  );
}
