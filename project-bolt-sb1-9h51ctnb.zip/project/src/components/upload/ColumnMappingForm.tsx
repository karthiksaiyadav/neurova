import { COLUMN_LABELS, ALL_COLUMNS, type GrainColumn } from "@/lib/grain/csv";

interface ColumnMappingFormProps {
  headers: string[];
  mapping: Record<string, GrainColumn | "">;
  onChange: (key: string, value: GrainColumn | "") => void;
}

export function ColumnMappingForm({ headers, mapping, onChange }: ColumnMappingFormProps) {
  return (
    <div className="space-y-2">
      {headers.map((header) => {
        const mapped = mapping[header] ?? "";
        return (
          <div
            key={header}
            className="flex flex-col gap-2 rounded-xl border border-secondary-200 bg-secondary-50/50 px-3 py-2.5 sm:flex-row sm:items-center sm:justify-between"
          >
            <div className="flex items-center gap-2">
              <span className="font-mono text-xs text-secondary-500">{header}</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-secondary-300">→</span>
              <select
                value={mapped}
                onChange={(e) => onChange(header, e.target.value as GrainColumn | "")}
                className={`rounded-lg border px-3 py-1.5 text-xs font-medium transition-colors ${
                  mapped
                    ? "border-primary-300 bg-primary-50 text-primary-700"
                    : "border-secondary-300 bg-white text-secondary-500"
                }`}
              >
                <option value="">— Skip —</option>
                {ALL_COLUMNS.map((col) => (
                  <option key={col} value={col}>
                    {COLUMN_LABELS[col]}
                  </option>
                ))}
              </select>
            </div>
          </div>
        );
      })}
    </div>
  );
}
