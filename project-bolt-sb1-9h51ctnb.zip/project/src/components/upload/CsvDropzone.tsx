import { useCallback, useRef, useState, type DragEvent } from "react";
import { FileText, UploadCloud } from "lucide-react";

interface CsvDropzoneProps {
  onFile: (file: File) => void;
  busy: boolean;
  fileName?: string;
}

export function CsvDropzone({ onFile, busy, fileName }: CsvDropzoneProps) {
  const [dragging, setDragging] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  const handleDrop = useCallback(
    (e: DragEvent) => {
      e.preventDefault();
      setDragging(false);
      const file = e.dataTransfer.files?.[0];
      if (file) onFile(file);
    },
    [onFile],
  );

  return (
    <div
      onDragOver={(e) => {
        e.preventDefault();
        setDragging(true);
      }}
      onDragLeave={() => setDragging(false)}
      onDrop={handleDrop}
      onClick={() => inputRef.current?.click()}
      role="button"
      tabIndex={0}
      onKeyDown={(e) => {
        if (e.key === "Enter" || e.key === " ") {
          e.preventDefault();
          inputRef.current?.click();
        }
      }}
      className={`group relative flex cursor-pointer flex-col items-center justify-center rounded-2xl border-2 border-dashed px-6 py-12 text-center transition-all duration-200 ${
        dragging
          ? "border-primary-500 bg-primary-50 scale-[1.01]"
          : busy
            ? "border-secondary-300 bg-secondary-50"
            : "border-secondary-300 bg-white hover:border-primary-400 hover:bg-primary-50/30"
      }`}
    >
      <input
        ref={inputRef}
        type="file"
        accept=".csv,.txt,.tsv,text/csv"
        className="hidden"
        onChange={(e) => {
          const file = e.target.files?.[0];
          if (file) onFile(file);
          e.target.value = "";
        }}
      />

      {busy ? (
        <div className="flex flex-col items-center gap-3">
          <div className="h-10 w-10 animate-spin rounded-full border-3 border-secondary-200 border-t-primary-500" />
          <p className="text-sm text-secondary-500">Reading file…</p>
        </div>
      ) : fileName ? (
        <div className="flex flex-col items-center gap-3">
          <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-success-100 text-success-700">
            <FileText className="h-6 w-6" />
          </div>
          <div>
            <p className="text-sm font-medium text-secondary-900">{fileName}</p>
            <p className="mt-0.5 text-xs text-secondary-400">Click to replace or drop a new file</p>
          </div>
        </div>
      ) : (
        <div className="flex flex-col items-center gap-3">
          <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-secondary-100 text-secondary-400 transition-colors group-hover:bg-primary-100 group-hover:text-primary-600">
            <UploadCloud className="h-6 w-6" />
          </div>
          <div>
            <p className="text-sm font-medium text-secondary-700">
              Drop your CSV here, or <span className="text-primary-600 underline">browse</span>
            </p>
            <p className="mt-0.5 text-xs text-secondary-400">CSV, TSV or semicolon-delimited · max 20 MB</p>
          </div>
        </div>
      )}
    </div>
  );
}
