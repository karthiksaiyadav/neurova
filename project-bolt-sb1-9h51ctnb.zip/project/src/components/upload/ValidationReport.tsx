import { AlertTriangle, CheckCircle2, Info, XCircle } from "lucide-react";
import type { ColumnStats, GrainColumn, ValidationIssue } from "@/lib/grain/csv";
import { COLUMN_LABELS } from "@/lib/grain/csv";

interface ValidationReportProps {
  issues: ValidationIssue[];
  stats: Partial<Record<GrainColumn, ColumnStats>>;
  missing: Partial<Record<GrainColumn, number>>;
}

export function ValidationReport({ issues, stats, missing }: ValidationReportProps) {
  const errors = issues.filter((i) => i.level === "error");
  const warnings = issues.filter((i) => i.level === "warning");

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        <SummaryTile icon={<XCircle className="h-4 w-4" />} label="Errors" value={errors.length} color="destructive" />
        <SummaryTile icon={<AlertTriangle className="h-4 w-4" />} label="Warnings" value={warnings.length} color="warning" />
        <SummaryTile icon={<CheckCircle2 className="h-4 w-4" />} label="OK rows" value={issues.length === 0 ? "All" : "—"} color="success" />
        <SummaryTile icon={<Info className="h-4 w-4" />} label="Total issues" value={issues.length} color="secondary" />
      </div>

      {Object.entries(missing).some(([, v]) => (v ?? 0) > 0) ? (
        <div className="rounded-xl border border-warning bg-warning-soft p-3">
          <p className="text-xs font-semibold text-warning-foreground">Missing values</p>
          <div className="mt-2 flex flex-wrap gap-2">
            {Object.entries(missing).map(([col, count]) =>
              (count ?? 0) > 0 ? (
                <span
                  key={col}
                  className="rounded-full border border-warning bg-white px-2.5 py-0.5 text-[11px] font-medium text-warning-foreground"
                >
                  {COLUMN_LABELS[col as GrainColumn]}: {count?.toLocaleString()}
                </span>
              ) : null,
            )}
          </div>
        </div>
      ) : null}

      {issues.length > 0 ? (
        <div className="max-h-48 space-y-1.5 overflow-y-auto scrollbar-thin pr-1">
          {issues.slice(0, 50).map((issue, i) => (
            <div
              key={i}
              className={`flex items-start gap-2 rounded-lg px-3 py-2 text-xs ${
                issue.level === "error"
                  ? "bg-destructive-soft text-destructive-foreground"
                  : "bg-warning-soft text-warning-foreground"
              }`}
            >
              {issue.level === "error" ? (
                <XCircle className="mt-0.5 h-3.5 w-3.5 shrink-0" />
              ) : (
                <AlertTriangle className="mt-0.5 h-3.5 w-3.5 shrink-0" />
              )}
              <span>{issue.message}</span>
            </div>
          ))}
          {issues.length > 50 && (
            <p className="px-3 py-1 text-[11px] text-secondary-400">…and {issues.length - 50} more</p>
          )}
        </div>
      ) : (
        <div className="flex items-center gap-2 rounded-xl border border-success-200 bg-success-soft px-3 py-2.5 text-xs text-success-foreground">
          <CheckCircle2 className="h-4 w-4" />
          All rows passed validation. No errors or warnings.
        </div>
      )}

      <div className="space-y-2">
        <p className="text-xs font-semibold text-secondary-700">Column statistics</p>
        <div className="grid grid-cols-1 gap-2 sm:grid-cols-2 lg:grid-cols-4">
          {Object.entries(stats).map(([col, s]) =>
            s ? (
              <div key={col} className="rounded-xl border border-secondary-200 bg-secondary-50 p-3">
                <p className="text-[11px] font-medium text-secondary-500">{COLUMN_LABELS[col as GrainColumn]}</p>
                <div className="mt-1.5 space-y-0.5 text-xs tabular-nums text-secondary-700">
                  <p>min <span className="font-medium">{s.min ?? "—"}{s.unit}</span></p>
                  <p>avg <span className="font-medium">{s.mean !== null ? s.mean.toFixed(1) : "—"}{s.unit}</span></p>
                  <p>max <span className="font-medium">{s.max ?? "—"}{s.unit}</span></p>
                </div>
              </div>
            ) : null,
          )}
        </div>
      </div>
    </div>
  );
}

function SummaryTile({
  icon,
  label,
  value,
  color,
}: {
  icon: React.ReactNode;
  label: string;
  value: number | string;
  color: "destructive" | "warning" | "success" | "secondary";
}) {
  const colorMap = {
    destructive: "text-destructive-600 bg-destructive-soft",
    warning: "text-warning-foreground bg-warning-soft",
    success: "text-success-foreground bg-success-soft",
    secondary: "text-secondary-600 bg-secondary-100",
  };

  return (
    <div className="flex items-center gap-2.5 rounded-xl border border-secondary-200 bg-white p-3">
      <div className={`flex h-8 w-8 items-center justify-center rounded-lg ${colorMap[color]}`}>{icon}</div>
      <div>
        <p className="text-lg font-bold tabular-nums text-secondary-900">{value}</p>
        <p className="text-[11px] text-secondary-400">{label}</p>
      </div>
    </div>
  );
}
