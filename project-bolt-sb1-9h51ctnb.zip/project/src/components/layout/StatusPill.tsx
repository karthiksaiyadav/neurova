import { useDataset } from "@/lib/dataset/DatasetContext";

export function StatusPill() {
  const { isLoaded, isSample, fileName, score } = useDataset();

  if (!isLoaded) {
    return (
      <span className="inline-flex items-center gap-1.5 rounded-full border border-secondary-300 bg-white px-3 py-1 text-[11px] font-semibold uppercase tracking-wider text-secondary-500">
        <span className="h-1.5 w-1.5 rounded-full bg-secondary-400" />
        No dataset
      </span>
    );
  }

  const label = isSample ? "Sample data" : fileName ?? "Loaded";
  const scoreColor =
    score && score.overall >= 80
      ? "bg-success-500"
      : score && score.overall >= 60
        ? "bg-warning-400"
        : "bg-destructive-500";

  return (
    <span className="inline-flex items-center gap-1.5 rounded-full border border-secondary-300 bg-white px-3 py-1 text-[11px] font-semibold uppercase tracking-wider text-secondary-700" title={label}>
      <span className={`h-1.5 w-1.5 rounded-full ${scoreColor}`} />
      {score ? `Score ${score.overall}` : "Loaded"}
    </span>
  );
}
