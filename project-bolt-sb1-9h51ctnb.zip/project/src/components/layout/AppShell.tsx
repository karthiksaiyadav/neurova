import { Wheat } from "lucide-react";
import type { ReactNode } from "react";
import { useDataset } from "@/lib/dataset/DatasetContext";
import { StatusPill } from "./StatusPill";

interface NavItem {
  label: string;
  page: string;
  icon: ReactNode;
}

const NAV_ITEMS: NavItem[] = [
  { label: "Upload", page: "upload", icon: <UploadIcon /> },
  { label: "Live", page: "live", icon: <LiveIcon /> },
  { label: "Dashboard", page: "dashboard", icon: <DashboardIcon /> },
  { label: "Bins", page: "bins", icon: <BinsIcon /> },
  { label: "Trends", page: "trends", icon: <TrendsIcon /> },
];

function UploadIcon() {
  return (
    <svg className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M7 16a4 4 0 01-.88-7.9 5 5 0 019.9-1.1A4.5 4.5 0 0117 16M9 13l3-3 3 3M12 10v8" />
    </svg>
  );
}

function DashboardIcon() {
  return (
    <svg className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M4 5a1 1 0 011-1h4a1 1 0 011 1v6a1 1 0 01-1 1H5a1 1 0 01-1-1V5zM14 5a1 1 0 011-1h4a1 1 0 011 1v3a1 1 0 01-1 1h-4a1 1 0 01-1-1V5zM14 13a1 1 0 011-1h4a1 1 0 011 1v6a1 1 0 01-1 1h-4a1 1 0 01-1-1v-6zM4 17a1 1 0 011-1h4a1 1 0 011 1v2a1 1 0 01-1 1H5a1 1 0 01-1-1v-2z" />
    </svg>
  );
}

function BinsIcon() {
  return (
    <svg className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M3 9l9-6 9 6M5 9v10a1 1 0 001 1h12a1 1 0 001-1V9M9 20v-6h6v6" />
    </svg>
  );
}

function LiveIcon() {
  return (
    <svg className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M3 12h2l2-6 4 12 2-6h2l2 3h4" />
    </svg>
  );
}

function TrendsIcon() {
  return (
    <svg className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M3 17l6-6 4 4 7-7M17 8h4v4" />
    </svg>
  );
}

interface AppShellProps {
  currentPage: string;
  onNavigate: (page: string) => void;
  children: ReactNode;
}

export function AppShell({ currentPage, onNavigate, children }: AppShellProps) {
  const { isLoaded } = useDataset();

  return (
    <div className="min-h-screen bg-secondary-50">
      <header className="sticky top-0 z-30 border-b border-secondary-200 bg-white/90 backdrop-blur-md">
        <div className="mx-auto flex h-14 max-w-7xl items-center gap-6 px-4 sm:px-6">
          <button
            onClick={() => onNavigate("upload")}
            className="flex items-center gap-2 transition-opacity hover:opacity-80"
          >
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary-600 text-white">
              <Wheat className="h-4 w-4" />
            </div>
            <span className="font-bold text-secondary-900">NEUROVA <span className="font-medium text-secondary-400">CSV Lab</span></span>
          </button>

          <nav className="hidden items-center gap-1 sm:flex">
            {NAV_ITEMS.map((item) => {
              const disabled = !isLoaded && item.page !== "upload" && item.page !== "live";
              return (
                <button
                  key={item.page}
                  onClick={() => !disabled && onNavigate(item.page)}
                  disabled={disabled}
                  className={`flex items-center gap-2 rounded-lg px-3 py-1.5 text-sm font-medium transition-all ${
                    currentPage === item.page
                      ? "bg-primary-50 text-primary-700"
                      : disabled
                        ? "text-secondary-300"
                        : "text-secondary-600 hover:bg-secondary-100"
                  }`}
                >
                  {item.icon}
                  {item.label}
                </button>
              );
            })}
          </nav>

          <div className="ml-auto flex items-center gap-3">
            <StatusPill />
          </div>
        </div>

        <nav className="flex items-center gap-1 overflow-x-auto px-4 pb-2 sm:hidden">
          {NAV_ITEMS.map((item) => {
            const disabled = !isLoaded && item.page !== "upload" && item.page !== "live";
            return (
              <button
                key={item.page}
                onClick={() => !disabled && onNavigate(item.page)}
                disabled={disabled}
                className={`flex items-center gap-2 rounded-lg px-3 py-1.5 text-sm font-medium transition-all whitespace-nowrap ${
                  currentPage === item.page
                    ? "bg-primary-50 text-primary-700"
                    : disabled
                      ? "text-secondary-300"
                      : "text-secondary-600 hover:bg-secondary-100"
                }`}
              >
                {item.icon}
                {item.label}
              </button>
            );
          })}
        </nav>
      </header>

      <main className="mx-auto max-w-7xl px-4 py-8 sm:px-6">
        {children}
      </main>

      <footer className="border-t border-secondary-200 bg-white">
        <div className="mx-auto max-w-7xl px-4 py-6 sm:px-6">
          <p className="text-xs text-secondary-400">
            NEUROVA CSV Lab — grain-storage monitoring. CSV analysis runs in your browser; live readings are sent from the ESP32 via Supabase.
          </p>
        </div>
      </footer>
    </div>
  );
}
